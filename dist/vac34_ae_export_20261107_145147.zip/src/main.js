/**
 * vac34_AE — Master Expressions Studio
 * Version 0.0.1
 * Entry Point
 */

try {
    if (typeof vac34_UIBuilder !== "undefined") {
        var win = vac34_UIBuilder.build(thisObj);
        if (typeof Window !== "undefined" && (win instanceof Window)) {
            win.center();
            win.show();
        }
    }
} catch (e) {
    if (typeof alert !== "undefined") {
        alert("vac34_AE Initialization Error: " + e.message + "\nLine: " + e.line);
    }
}
