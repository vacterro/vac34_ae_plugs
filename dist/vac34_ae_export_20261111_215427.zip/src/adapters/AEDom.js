/*
 * vac34_AE — Master Expressions Studio
 * AE DOM Adapter: Safe interaction with After Effects Object Model
 */

var vac34_AEDom = (function() {
    var _undoDepth = 0;

    return {
        getActiveComp: function() {
            if (typeof app !== "undefined" && app.project && app.project.activeItem && (app.project.activeItem instanceof CompItem)) {
                return app.project.activeItem;
            }
            return null;
        },

        getSelectedLayers: function(comp) {
            if (!comp) comp = this.getActiveComp();
            if (!comp) return [];
            var layers = [];
            for (var i = 0; i < comp.selectedLayers.length; i++) {
                layers.push(comp.selectedLayers[i]);
            }
            return layers;
        },

        beginUndo: function(name) {
            try {
                if (_undoDepth === 0 && typeof app !== "undefined" && app.beginUndoGroup) {
                    app.beginUndoGroup(name || "vac34_AE Action");
                }
                _undoDepth++;
            } catch (e) {
                _undoDepth = 0;
            }
        },

        endUndo: function() {
            try {
                if (_undoDepth > 0) {
                    _undoDepth--;
                    if (_undoDepth === 0 && typeof app !== "undefined" && app.endUndoGroup) {
                        app.endUndoGroup();
                    }
                }
            } catch (e) {
                _undoDepth = 0;
            }
        },

        getUndoDepth: function() {
            return _undoDepth;
        },

        resolveProperty: function(layer, propPath) {
            if (!layer) return null;
            var parts = propPath.split(".");
            var current = layer;
            for (var i = 0; i < parts.length; i++) {
                var p = parts[i];
                try {
                    if (current.property) {
                        current = current.property(p);
                    } else {
                        return null;
                    }
                } catch (e) {
                    return null;
                }
                if (!current) return null;
            }
            return current;
        },

        canSetExpression: function(prop) {
            if (!prop) return false;
            try {
                if (prop.dimensionsSeparated === true) {
                    return false;
                }
                return (prop.canSetExpression === true);
            } catch (e) {
                return false;
            }
        },

        isVac34Expression: function(prop) {
            if (!prop || !prop.expression) return false;
            var expr = prop.expression.replace(/^\s+/, "");
            return (expr.indexOf(vac34_Config.TAG_PREFIX) === 0);
        },

        extractVac34RecipeId: function(prop) {
            if (!prop || !prop.expression) return null;
            var expr = prop.expression.replace(/^\s+/, "");
            if (expr.indexOf(vac34_Config.TAG_PREFIX) !== 0) return null;
            var start = vac34_Config.TAG_PREFIX.length;
            var end = expr.indexOf(vac34_Config.TAG_SUFFIX, start);
            if (end !== -1) {
                return expr.substring(start, end).replace(/^\s+|\s+$/g, "");
            }
            return null;
        },

        findRecipeProperties: function(layer, recipeId) {
            var found = [];
            if (!layer || typeof layer.property !== "function") return found;
            var self = this;

            function searchGroup(group) {
                if (!group || !group.numProperties) return;
                for (var i = 1; i <= group.numProperties; i++) {
                    try {
                        var p = group.property(i);
                        if (!p) continue;
                        if (self.canSetExpression(p)) {
                            if (self.isVac34Expression(p)) {
                                if (!recipeId || self.extractVac34RecipeId(p) === recipeId) {
                                    found.push(p);
                                }
                            }
                        } else if (p.numProperties && p.numProperties > 0) {
                            searchGroup(p);
                        }
                    } catch (e) {}
                }
            }

            var xform = layer.property("Transform");
            if (xform) searchGroup(xform);

            var effects = layer.property("ADBE Effect Parade") || layer.property("Effects");
            if (effects) searchGroup(effects);

            return found;
        },

        findRecipeProperty: function(layer, recipeId) {
            var props = this.findRecipeProperties(layer, recipeId);
            return (props.length > 0) ? props[0] : null;
        },

        hasForeignExpression: function(prop) {
            if (!prop || !prop.expression) return false;
            var trimmed = prop.expression.replace(/^\s+|\s+$/g, "");
            if (trimmed === "") return false;
            return !this.isVac34Expression(prop);
        },

        classifyExpression: function(prop, targetRecipeId) {
            if (!prop || !prop.expression) return { state: "NONE", recipeId: null };
            var expr = prop.expression.replace(/^\s+|\s+$/g, "");
            if (expr === "") return { state: "NONE", recipeId: null };
            if (!this.isVac34Expression(prop)) {
                return { state: "FOREIGN", recipeId: null, expression: expr };
            }
            var existingRecipeId = this.extractVac34RecipeId(prop);
            if (!existingRecipeId) {
                return { state: "DAMAGED", recipeId: null };
            }
            if (!targetRecipeId || existingRecipeId === targetRecipeId) {
                return { state: "SAME_RECIPE", recipeId: existingRecipeId };
            }
            return { state: "DIFFERENT_RECIPE", recipeId: existingRecipeId };
        },

        verifyExpressionState: function(prop) {
            if (!prop) return { ok: false, error: "Property reference is null" };
            try {
                if (prop.expressionError && prop.expressionError.length > 0) {
                    return { ok: false, error: prop.expressionError };
                }
                if (prop.canSetExpression && prop.expression && prop.expression.length > 0 && prop.expressionEnabled === false) {
                    return { ok: false, error: "Expression was disabled by host due to error." };
                }
                return { ok: true, error: null };
            } catch (e) {
                return { ok: false, error: e.message || String(e) };
            }
        },

        capturePropertyDescriptor: function(layer, prop) {
            if (!prop) return null;
            var ownerLyr = layer;
            if (!ownerLyr && typeof vac34_TargetResolver !== "undefined") {
                ownerLyr = vac34_TargetResolver.resolveOwnerLayer(prop);
            }

            var pathParts = [];
            var indexPath = [];
            var cur = prop;
            var effectNode = null;
            var effectIndex = -1;
            var effectMatchName = "";
            var effectName = "";
            var guard = 25;

            while (cur && guard-- > 0) {
                if (cur.propertyIndex !== undefined) {
                    indexPath.unshift(cur.propertyIndex);
                } else if (cur.name) {
                    indexPath.unshift(cur.name);
                }
                if (cur.name) {
                    pathParts.unshift(cur.name);
                }
                try {
                    var parent = cur.parentProperty;
                    if (!parent) break;
                    var parentName = parent.name || "";
                    var parentMatch = parent.matchName || "";
                    if (parentMatch === "ADBE Effect Parade" || parentName === "Effects" || parentName === "ADBE Effect Parade") {
                        effectNode = cur;
                        effectIndex = (cur.propertyIndex !== undefined) ? cur.propertyIndex : -1;
                        effectMatchName = cur.matchName || "";
                        effectName = cur.name || "";
                    }
                    if (ownerLyr && (parent === ownerLyr || cur === ownerLyr)) break;
                    cur = parent;
                } catch (e) {
                    break;
                }
            }

            var subChain = [];
            if (effectNode) {
                var c = prop;
                var g2 = 15;
                while (c && c !== effectNode && g2-- > 0) {
                    if (c.propertyIndex !== undefined) {
                        subChain.unshift(c.propertyIndex);
                    } else if (c.name) {
                        subChain.unshift(c.name);
                    }
                    c = c.parentProperty;
                }
            }

            return {
                layerIndex: ownerLyr ? (ownerLyr.index !== undefined ? ownerLyr.index : null) : null,
                layerName: ownerLyr ? (ownerLyr.name || "") : "",
                name: prop.name || "",
                matchName: prop.matchName || "",
                path: pathParts.join(" > "),
                indexPath: indexPath,
                isEffect: !!effectNode,
                effectIndex: effectIndex,
                effectMatchName: effectMatchName,
                effectName: effectName,
                subChain: subChain
            };
        },

        reacquireProperty: function(layer, descriptor) {
            if (!layer || !descriptor) return null;
            try {
                if (descriptor.isEffect) {
                    var effectsGroup = layer.property("ADBE Effect Parade") || layer.property("Effects");
                    if (!effectsGroup) return null;

                    function descriptorNameMatches(e) {
                        if (!e) return false;
                        var mOk = !descriptor.effectMatchName || e.matchName === descriptor.effectMatchName;
                        var nOk = !descriptor.effectName || e.name === descriptor.effectName;
                        return mOk && nOk;
                    }

                    var eff = null;
                    // 1. Try by verified original effectIndex
                    if (descriptor.effectIndex > 0 && descriptor.effectIndex <= effectsGroup.numProperties) {
                        var candidate = effectsGroup.property(descriptor.effectIndex);
                        if (descriptorNameMatches(candidate)) {
                            eff = candidate;
                        }
                    }

                    // 2. No index-verified hit: name+matchName are NOT unique identity.
                    //    Accept only a sole, unambiguous matching instance; duplicates fail closed.
                    if (!eff && effectsGroup.numProperties) {
                        var soleMatch = null;
                        var matchCount = 0;
                        for (var i = 1; i <= effectsGroup.numProperties; i++) {
                            var e = effectsGroup.property(i);
                            if (descriptorNameMatches(e)) {
                                matchCount++;
                                soleMatch = e;
                            }
                        }
                        eff = (matchCount === 1) ? soleMatch : null;
                    }

                    if (!eff) return null;

                    // Navigate subChain from effect down to the target property
                    var target = eff;
                    if (descriptor.subChain && descriptor.subChain.length > 0) {
                        for (var s = 0; s < descriptor.subChain.length; s++) {
                            var subKey = descriptor.subChain[s];
                            if (typeof target.property === "function") {
                                target = target.property(subKey);
                            } else {
                                target = null;
                                break;
                            }
                            if (!target) break;
                        }
                    }
                    if (target) {
                        if (descriptor.matchName && target.matchName && target.matchName !== descriptor.matchName) {
                            return null;
                        }
                        return target;
                    }
                    return null;
                }

                // Transform or layer-level property: navigate indexPath
                var current = layer;
                if (descriptor.indexPath && descriptor.indexPath.length > 0) {
                    for (var p = 0; p < descriptor.indexPath.length; p++) {
                        if (typeof current.property === "function") {
                            current = current.property(descriptor.indexPath[p]);
                        } else {
                            current = null;
                            break;
                        }
                        if (!current) break;
                    }
                    if (current) return current;
                }

                return null;
            } catch (err) {
                return null;
            }
        },

        isLayer3D: function(layer) {
            if (!layer) return false;
            try {
                return (layer.threeDLayer === true);
            } catch (e) {
                return false;
            }
        },

        getPropertyDimension: function(layer, prop) {
            if (!prop) return 0;
            try {
                if (typeof PropertyValueType !== "undefined") {
                    if (prop.propertyValueType === PropertyValueType.OneD) return 1;
                    if (prop.propertyValueType === PropertyValueType.TwoD || prop.propertyValueType === PropertyValueType.TwoD_SPATIAL) {
                        if (this.isLayer3D(layer)) {
                            var mName = prop.matchName || "";
                            if (mName === "ADBE Position" || mName === "ADBE Scale" || mName === "ADBE Anchor Point") {
                                return 3;
                            }
                        }
                        return 2;
                    }
                    if (prop.propertyValueType === PropertyValueType.ThreeD || prop.propertyValueType === PropertyValueType.ThreeD_SPATIAL) return 3;
                    if (prop.propertyValueType === PropertyValueType.COLOR) return 4;
                    if (prop.propertyValueType === PropertyValueType.TEXT_DOCUMENT) return "text";
                }
                // Fallbacks
                if (prop.propertyValueType === 1) return 1;
                if (prop.propertyValueType === 2) {
                    if (this.isLayer3D(layer)) return 3;
                    return 2;
                }
                if (prop.propertyValueType === 3) return 3;
                if (prop.propertyValueType === 4) return 4;
                if (prop.propertyValueType === 7) return "text";

                if (prop.value instanceof Array) {
                    return prop.value.length;
                }
                if (typeof prop.value === "number") return 1;
                if (typeof prop.value === "string") return "text";
            } catch (e) {}
            return 1;
        }
    };
})();
