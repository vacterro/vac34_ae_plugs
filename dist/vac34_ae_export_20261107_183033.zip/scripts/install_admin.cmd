@echo off
setlocal enabledelayedexpansion
title vac34_AE Live Panel Elevated Installer

:: Guard against infinite recursion loop
if "%~1"=="--elevated" goto :run_install

:: Robust Administrator check using fltmc (never net session, which fails when Server service is disabled)
fltmc >nul 2>&1
if %errorlevel% equ 0 goto :run_install

echo [REQUESTING ELEVATION] Restarting with Administrator privileges...
powershell -NoProfile -Command "Start-Process cmd.exe -ArgumentList '/c ""%~f0" --elevated"' -Verb RunAs"
exit /b

:run_install
cd /d "%~dp0.."
set "SCRIPT_DIR=%~dp0"
set "INSTALL_PY=%SCRIPT_DIR%install_live.py"

echo ========================================================
echo  vac34_AE — Master Expressions Studio Live Installer
echo ========================================================
echo.

where python >nul 2>&1
if %errorlevel% equ 0 (
    python "%INSTALL_PY%"
    set "EXIT_CODE=!errorlevel!"
) else (
    py -3 "%INSTALL_PY%"
    set "EXIT_CODE=!errorlevel!"
)

if !EXIT_CODE! equ 0 (
    echo.
    echo [SUCCESS] Elevated installation completed and verified!
) else (
    echo.
    echo [ERROR] Installation failed with exit code !EXIT_CODE!.
)

echo.
echo Press any key to close this window.
pause >nul
exit /b !EXIT_CODE!
