/*
 * vac34_AE — Master Expressions Studio
 * Engine: Execution Orchestrator with Rigorous Dependency Validation & Reversible Transactions
 */

var vac34_Engine = (function() {
    function findVac34PropertyOnLayer(layer, recipeId) {
        if (!layer) return null;
        // Check transform properties
        var xform = layer.property("Transform");
        if (xform) {
            for (var p = 1; p <= xform.numProperties; p++) {
                var prop = xform.property(p);
                if (prop && vac34_AEDom.isVac34Expression(prop)) {
                    if (!recipeId || vac34_AEDom.extractVac34RecipeId(prop) === recipeId) {
                        return prop;
                    }
                }
            }
        }
        return null;
    }

    return {
        applyRecipe: function(comp, layers, recipe, paramValues, isMasterMode, audioName, audioChan, targetMode) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);
            if (!recipe) return { ok: false, message: "No behavior recipe selected." };

            // P0: Audio Source Validation
            if (recipe.requiresAudio) {
                var audioVal = vac34_AudioEngine.validateAudioSource(comp, audioName, audioChan);
                if (!audioVal.valid) {
                    return {
                        ok: false,
                        appliedCount: 0,
                        failedCount: 1,
                        conflictCount: 0,
                        skipCount: 0,
                        message: audioVal.message,
                        warnings: []
                    };
                }
            }

            // P0: Universal Target Resolution
            var targetRes = (typeof vac34_TargetResolver !== "undefined")
                ? vac34_TargetResolver.resolveTargets(comp, layers, recipe, targetMode)
                : { ok: false, targets: [], message: "TargetResolver not available." };

            if (!targetRes.ok || targetRes.targets.length === 0) {
                return {
                    ok: false,
                    appliedCount: 0,
                    failedCount: 1,
                    conflictCount: 0,
                    skipCount: targetRes.incompatibleCount || 0,
                    message: targetRes.message,
                    warnings: []
                };
            }

            // Filter out foreign expressions to preserve byte-identical user expressions
            var validTargets = [];
            var foreignConflicts = [];
            for (var t = 0; t < targetRes.targets.length; t++) {
                var item = targetRes.targets[t];
                if (vac34_AEDom.hasForeignExpression(item.prop)) {
                    foreignConflicts.push(item);
                } else {
                    validTargets.push(item);
                }
            }

            if (foreignConflicts.length > 0 && validTargets.length === 0) {
                return {
                    ok: false,
                    appliedCount: 0,
                    failedCount: 0,
                    conflictCount: foreignConflicts.length,
                    skipCount: 0,
                    message: "Cannot apply: selected property has foreign expression which must not be overwritten.",
                    warnings: ["Preserved foreign expression on " + foreignConflicts[0].path]
                };
            }

            vac34_AEDom.beginUndo("vac34_AE: Apply " + recipe.displayName);
            var successCount = 0;
            var failureCount = 0;
            var warnings = [];
            var lastAppliedPath = "";

            try {
                var masterLayer = null;
                var masterControls = null;
                var masterIsNew = false;
                if (isMasterMode) {
                    masterLayer = vac34_ControllerManager.getOrCreateMasterLayer(comp);
                    if (!masterLayer) {
                        return { ok: false, appliedCount: 0, failedCount: validTargets.length, message: "Failed to create Shared Master Null." };
                    }
                    masterIsNew = !!masterLayer._vac34IsNew;
                    masterControls = vac34_ControllerManager.setupRecipeControls(masterLayer, recipe, paramValues);
                    if (!masterControls) {
                        if (masterIsNew) {
                            try { masterLayer.remove(); } catch (e) {}
                        }
                        return { ok: false, appliedCount: 0, failedCount: validTargets.length, message: "Failed to initialize Expression Controls on Master Null." };
                    }
                }

                for (var v = 0; v < validTargets.length; v++) {
                    var targetItem = validTargets[v];
                    var lyr = targetItem.layer;
                    var prop = targetItem.prop;
                    var ctrlMap = null;

                    if (!isMasterMode) {
                        ctrlMap = vac34_ControllerManager.setupRecipeControls(lyr, recipe, paramValues);
                        if (!ctrlMap) {
                            failureCount++;
                            warnings.push("Failed to create Expression Controls on layer '" + lyr.name + "'.");
                            continue;
                        }
                    }

                    var masterName = masterLayer ? masterLayer.name : vac34_Config.MASTER_LAYER_NAME;
                    var expr = recipe.generateExpression(lyr, isMasterMode, masterName, paramValues, audioName, audioChan);

                    try {
                        prop.expression = expr;
                        if (ctrlMap && ctrlMap._tx) {
                            ctrlMap._tx.commit();
                        }
                        successCount++;
                        lastAppliedPath = targetItem.path;
                    } catch (exprErr) {
                        if (ctrlMap && ctrlMap._tx) {
                            ctrlMap._tx.rollback();
                        }
                        failureCount++;
                        warnings.push("Expression assignment failed on " + targetItem.path + ": " + exprErr.message);
                    }
                }

                if (isMasterMode && masterControls && masterControls._tx) {
                    if (successCount === 0) {
                        masterControls._tx.rollback();
                        if (masterIsNew && masterLayer) {
                            try { masterLayer.remove(); } catch (eM) {}
                        }
                    } else {
                        masterControls._tx.commit();
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            var successMsg = "";
            if (successCount === 1) {
                successMsg = "Applied " + recipe.displayName + " to " + lastAppliedPath;
            } else if (successCount > 1) {
                successMsg = "Applied " + recipe.displayName + " to " + successCount + " properties.";
            } else {
                successMsg = "Failed to apply " + recipe.displayName + ".";
            }

            return {
                ok: (successCount > 0),
                appliedCount: successCount,
                failedCount: failureCount,
                conflictCount: foreignConflicts.length,
                skipCount: targetRes.incompatibleCount || 0,
                message: successMsg,
                warnings: warnings
            };
        },

        updateParameters: function(comp, layers, recipe, paramValues, isMasterMode) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);
            if (!recipe || !paramValues) return { ok: false, updatedCount: 0, message: "Missing recipe or parameters." };

            vac34_AEDom.beginUndo("vac34_AE: Update " + recipe.displayName);
            var updatedCount = 0;

            try {
                if (isMasterMode) {
                    var master = vac34_ControllerManager.getOrCreateMasterLayer(comp);
                    if (master) {
                        for (var pId in paramValues) {
                            if (paramValues.hasOwnProperty(pId)) {
                                if (vac34_ControllerManager.updateParameterValue(master, recipe, pId, paramValues[pId])) {
                                    updatedCount++;
                                }
                            }
                        }
                    }
                } else {
                    for (var i = 0; i < layers.length; i++) {
                        var lyr = layers[i];
                        for (var pId in paramValues) {
                            if (paramValues.hasOwnProperty(pId)) {
                                if (vac34_ControllerManager.updateParameterValue(lyr, recipe, pId, paramValues[pId])) {
                                    updatedCount++;
                                }
                            }
                        }
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            var ok = (updatedCount > 0);
            return {
                ok: ok,
                updatedCount: updatedCount,
                message: ok ? "Successfully updated " + updatedCount + " parameter value(s)." : "No matching active controls found to update."
            };
        },

        removeRecipe: function(comp, layers, recipe) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);
            if (!recipe) return { ok: false, removedCount: 0, message: "No recipe selected." };

            vac34_AEDom.beginUndo("vac34_AE: Remove " + recipe.displayName);
            var removedCount = 0;

            try {
                for (var i = 0; i < layers.length; i++) {
                    var lyr = layers[i];
                    var ownedProps = (typeof vac34_AEDom.findRecipeProperties === "function")
                        ? vac34_AEDom.findRecipeProperties(lyr, recipe.id)
                        : [];

                    if (ownedProps.length === 0) {
                        // Fallback check
                        var fallbackProp = vac34_AEDom.findRecipeProperty(lyr, recipe.id);
                        if (fallbackProp) ownedProps.push(fallbackProp);
                    }

                    if (ownedProps.length > 0) {
                        for (var p = 0; p < ownedProps.length; p++) {
                            try {
                                ownedProps[p].expression = "";
                                removedCount++;
                            } catch (eExp) {}
                        }
                        // Only remove controls if this recipe actually owned expressions
                        vac34_ControllerManager.removeRecipeControls(lyr, recipe);
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            return {
                ok: (removedCount > 0),
                removedCount: removedCount,
                message: "Removed '" + recipe.displayName + "' from " + removedCount + " property(ies)."
            };
        }
    };
})();
