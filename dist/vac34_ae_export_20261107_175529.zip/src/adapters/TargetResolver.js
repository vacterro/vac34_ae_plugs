/*
 * vac34_AE — Master Expressions Studio
 * TargetResolver: Universal Selected-Property Target Resolution & Compatibility Engine
 */

var vac34_TargetResolver = (function() {
    var TARGET_MODES = {
        AUTO: "AUTO",
        SELECTED: "SELECTED_PROPERTY",
        DEFAULT: "RECIPE_DEFAULT"
    };

    var _currentTargetMode = TARGET_MODES.AUTO;

    function resolveOwnerLayer(prop) {
        if (!prop) return null;
        try {
            if (prop.propertyDepth && typeof prop.propertyGroup === "function") {
                var top = prop.propertyGroup(prop.propertyDepth);
                if (top && typeof top.property === "function") {
                    return top;
                }
            }
        } catch (e) {}

        var current = prop;
        var guard = 20;
        while (current && guard-- > 0) {
            try {
                if (current.parentProperty) {
                    current = current.parentProperty;
                } else if (typeof current.property === "function" && (current.containingComp !== undefined || current.numProperties !== undefined)) {
                    return current;
                } else {
                    break;
                }
            } catch (e2) {
                break;
            }
        }

        if (current && current !== prop && typeof current.property === "function") {
            return current;
        }
        return null;
    }

    function getPropertyPath(prop) {
        if (!prop) return "None";
        var parts = [prop.name || "Property"];
        var current = prop;
        var guard = 15;
        while (current && guard-- > 0) {
            try {
                if (current.parentProperty) {
                    current = current.parentProperty;
                    if (current && current.name) {
                        parts.unshift(current.name);
                    }
                } else {
                    break;
                }
            } catch (e) {
                break;
            }
        }
        return parts.join(" > ");
    }

    function getSelectedProperties(comp) {
        if (!comp) comp = vac34_AEDom.getActiveComp();
        if (!comp) return [];

        var props = [];
        var seen = {};

        // 1. Try comp.selectedProperties if host supports it
        try {
            if (comp.selectedProperties && comp.selectedProperties.length > 0) {
                for (var i = 0; i < comp.selectedProperties.length; i++) {
                    var cp = comp.selectedProperties[i];
                    if (cp && vac34_AEDom.canSetExpression(cp)) {
                        var cpPath = getPropertyPath(cp);
                        if (!seen[cpPath]) {
                            seen[cpPath] = true;
                            props.push(cp);
                        }
                    }
                }
            }
        } catch (eComp) {}

        // 2. Search across comp.selectedLayers
        if (comp.selectedLayers && comp.selectedLayers.length > 0) {
            for (var l = 0; l < comp.selectedLayers.length; l++) {
                var lyr = comp.selectedLayers[l];
                if (lyr && lyr.selectedProperties && lyr.selectedProperties.length > 0) {
                    for (var sp = 0; sp < lyr.selectedProperties.length; sp++) {
                        var p = lyr.selectedProperties[sp];
                        // Filter out property groups (e.g. effects folder or effect container without canSetExpression)
                        if (p && vac34_AEDom.canSetExpression(p)) {
                            // Deduplicate
                            var pPath = getPropertyPath(p);
                            if (!seen[pPath]) {
                                seen[pPath] = true;
                                props.push(p);
                            }
                        }
                    }
                }
            }
        }

        return props;
    }

    function inspectProperty(layer, prop) {
        if (!prop) return null;
        var ownerLyr = layer || resolveOwnerLayer(prop);
        var dim = vac34_AEDom.getPropertyDimension(ownerLyr, prop);
        var canSet = vac34_AEDom.canSetExpression(prop);
        var hasForeign = vac34_AEDom.hasForeignExpression(prop);
        var isVac = vac34_AEDom.isVac34Expression(prop);
        var val = null;
        try { val = prop.value; } catch (e) {}

        return {
            prop: prop,
            layer: ownerLyr,
            name: prop.name || "",
            matchName: prop.matchName || "",
            path: getPropertyPath(prop),
            propertyValueType: prop.propertyValueType,
            dimension: dim,
            canSetExpression: canSet,
            hasForeignExpression: hasForeign,
            isVac34: isVac,
            currentValue: val
        };
    }

    function checkPropertyCompatibility(inspected, recipe) {
        if (!inspected || !inspected.prop) {
            return { compatible: false, reason: "No property selected." };
        }
        if (!inspected.canSetExpression) {
            return { compatible: false, reason: "Property does not support expressions (canSetExpression is false)." };
        }
        if (!recipe) {
            return { compatible: false, reason: "No recipe selected." };
        }

        var expectedDim = recipe.targetDimensions || 2;
        var actualDim = inspected.dimension;

        // Special case: Universal Audio Mapper accepts any 1D scalar
        if (recipe.id === "audio.property.map.scalar") {
            if (actualDim === 1) {
                return { compatible: true, reason: "Compatible 1D numeric property." };
            } else {
                return { compatible: false, reason: "Recipe requires 1D scalar property, but property is " + actualDim + "D." };
            }
        }

        // Generic 1D recipes
        if (expectedDim === 1) {
            if (actualDim === 1) {
                return { compatible: true, reason: "Compatible 1D property." };
            } else {
                return { compatible: false, reason: "Recipe expects 1D property, but selected property is " + actualDim + "D." };
            }
        }

        // 2D recipes (e.g. Scale, Position)
        if (expectedDim === 2) {
            if (actualDim === 2 || actualDim === 3) {
                return { compatible: true, reason: "Compatible 2D/3D spatial property." };
            } else {
                return { compatible: false, reason: "Recipe expects 2D vector, but selected property is " + actualDim + "D (" + inspected.name + ")." };
            }
        }

        if (actualDim === expectedDim) {
            return { compatible: true, reason: "Compatible dimensions." };
        }

        return { compatible: false, reason: "Dimension mismatch: recipe expects " + expectedDim + "D, property is " + actualDim + "D." };
    }

    function resolveTargets(comp, layers, recipe, targetMode) {
        var mode = targetMode || _currentTargetMode;
        if (!comp) comp = vac34_AEDom.getActiveComp();
        if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);

        var selectedProps = getSelectedProperties(comp);
        var resolvedTargets = [];
        var incompatibleCount = 0;

        // MODE 1: SELECTED_PROPERTY (Strict)
        if (mode === TARGET_MODES.SELECTED) {
            if (selectedProps.length === 0) {
                return {
                    ok: false,
                    targets: [],
                    compatibleCount: 0,
                    incompatibleCount: 0,
                    message: "Cannot apply: No properties selected in Selected Property mode."
                };
            }

            for (var i = 0; i < selectedProps.length; i++) {
                var p = selectedProps[i];
                var lyr = resolveOwnerLayer(p) || (layers && layers[0]);
                var insp = inspectProperty(lyr, p);
                var compCheck = checkPropertyCompatibility(insp, recipe);
                if (compCheck.compatible) {
                    resolvedTargets.push({
                        layer: lyr,
                        prop: p,
                        inspected: insp,
                        path: insp.path
                    });
                } else {
                    incompatibleCount++;
                }
            }

            if (resolvedTargets.length === 0) {
                return {
                    ok: false,
                    targets: [],
                    compatibleCount: 0,
                    incompatibleCount: incompatibleCount,
                    message: "Cannot apply: selected property is incompatible with " + (recipe ? recipe.displayName : "behavior") + "."
                };
            }

            return {
                ok: true,
                targets: resolvedTargets,
                compatibleCount: resolvedTargets.length,
                incompatibleCount: incompatibleCount,
                message: "Resolved " + resolvedTargets.length + " target properties."
            };
        }

        // MODE 2: RECIPE_DEFAULT
        if (mode === TARGET_MODES.DEFAULT) {
            var targetPath = (recipe && recipe.targetProperties && recipe.targetProperties[0]) ? recipe.targetProperties[0] : "Transform.Position";
            if (!layers || layers.length === 0) {
                return { ok: false, targets: [], message: "Cannot apply: No layers selected." };
            }
            for (var lIdx = 0; lIdx < layers.length; lIdx++) {
                var dLyr = layers[lIdx];
                var dProp = vac34_AEDom.resolveProperty(dLyr, targetPath);
                if (dProp) {
                    var dInsp = inspectProperty(dLyr, dProp);
                    resolvedTargets.push({
                        layer: dLyr,
                        prop: dProp,
                        inspected: dInsp,
                        path: dInsp ? dInsp.path : (dLyr.name + " > " + targetPath)
                    });
                }
            }
            return {
                ok: resolvedTargets.length > 0,
                targets: resolvedTargets,
                compatibleCount: resolvedTargets.length,
                incompatibleCount: 0,
                message: "Resolved " + resolvedTargets.length + " default recipe targets."
            };
        }

        // MODE 3: AUTO (Intuitive)
        // If compatible properties are explicitly selected, prioritize them!
        if (selectedProps.length > 0) {
            for (var s = 0; s < selectedProps.length; s++) {
                var sProp = selectedProps[s];
                var sLyr = resolveOwnerLayer(sProp) || (layers && layers[0]);
                var sInsp = inspectProperty(sLyr, sProp);
                var sCheck = checkPropertyCompatibility(sInsp, recipe);
                if (sCheck.compatible) {
                    resolvedTargets.push({
                        layer: sLyr,
                        prop: sProp,
                        inspected: sInsp,
                        path: sInsp.path
                    });
                } else {
                    incompatibleCount++;
                }
            }

            if (resolvedTargets.length > 0) {
                return {
                    ok: true,
                    targets: resolvedTargets,
                    compatibleCount: resolvedTargets.length,
                    incompatibleCount: incompatibleCount,
                    message: "Targeting " + resolvedTargets.length + " selected properties."
                };
            }

            // User explicitly selected properties, but ALL of them are incompatible!
            // P0 requirement: Never silently substitute incompatible target!
            return {
                ok: false,
                targets: [],
                compatibleCount: 0,
                incompatibleCount: incompatibleCount,
                message: "Cannot apply: selected property is incompatible with " + (recipe ? recipe.displayName : "behavior") + "."
            };
        }

        // No properties explicitly selected: fallback to recipe default
        var autoPath = (recipe && recipe.targetProperties && recipe.targetProperties[0]) ? recipe.targetProperties[0] : "Transform.Position";
        if (layers && layers.length > 0) {
            for (var a = 0; a < layers.length; a++) {
                var aLyr = layers[a];
                var aProp = vac34_AEDom.resolveProperty(aLyr, autoPath);
                if (aProp) {
                    var aInsp = inspectProperty(aLyr, aProp);
                    resolvedTargets.push({
                        layer: aLyr,
                        prop: aProp,
                        inspected: aInsp,
                        path: aInsp ? aInsp.path : (aLyr.name + " > " + autoPath)
                    });
                }
            }
        }

        return {
            ok: resolvedTargets.length > 0,
            targets: resolvedTargets,
            compatibleCount: resolvedTargets.length,
            incompatibleCount: 0,
            message: "Targeting recipe default (" + autoPath + ")."
        };
    }

    function getPreviewSummary(comp, layers, recipe, targetMode) {
        var res = resolveTargets(comp, layers, recipe, targetMode);
        if (!res.ok) {
            if (res.incompatibleCount > 0) {
                return "Incompatible selection (" + res.incompatibleCount + " rejected)";
            }
            return "No target resolved";
        }
        if (res.targets.length === 1) {
            return "Target: " + res.targets[0].path;
        }
        if (res.targets.length > 1) {
            return "Targets: " + res.compatibleCount + " compatible" + (res.incompatibleCount > 0 ? (" / " + res.incompatibleCount + " incompatible") : "");
        }
        return "Target: None";
    }

    return {
        TARGET_MODES: TARGET_MODES,
        getTargetMode: function() { return _currentTargetMode; },
        setTargetMode: function(m) { _currentTargetMode = m; },
        resolveOwnerLayer: resolveOwnerLayer,
        getPropertyPath: getPropertyPath,
        getSelectedProperties: getSelectedProperties,
        inspectProperty: inspectProperty,
        checkPropertyCompatibility: checkPropertyCompatibility,
        resolveTargets: resolveTargets,
        getPreviewSummary: getPreviewSummary
    };
})();
