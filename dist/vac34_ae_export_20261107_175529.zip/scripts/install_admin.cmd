@echo off
setlocal enabledelayedexpansion
title vac34_AE Live Panel Elevated Installer

:: Check for Administrator elevation
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [REQUESTING ELEVATION] Restarting with Administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ========================================================
echo  vac34_AE — Master Expressions Studio Live Installer
echo ========================================================
echo.

set "SCRIPT_DIR=%~dp0"
set "WORKSPACE_ROOT=%SCRIPT_DIR%.."
set "INSTALL_PY=%SCRIPT_DIR%install_live.py"

:: Check python availability and run install_live.py
where python >nul 2>&1
if %errorLevel% equ 0 (
    python "%INSTALL_PY%"
    set "EXIT_CODE=!errorLevel!"
) else (
    py -3 "%INSTALL_PY%"
    set "EXIT_CODE=!errorLevel!"
)

if !EXIT_CODE! equ 0 (
    echo.
    echo [SUCCESS] Elevated installation completed and verified!
) else (
    echo.
    echo [ERROR] Installation failed with exit code !EXIT_CODE!.
)

echo.
echo Press any key to close this window.
pause >nul
exit /b !EXIT_CODE!
