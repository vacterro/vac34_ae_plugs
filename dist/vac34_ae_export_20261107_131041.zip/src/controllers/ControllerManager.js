/*
 * vac34_AE — Master Expressions Studio
 * ControllerManager: Strict Native AE Expression Controls Orchestration & Reversible Transactions
 */

var vac34_ControllerManager = (function() {
    var MATCH_NAMES = {
        "slider": "ADBE Slider Control",
        "checkbox": "ADBE Checkbox Control",
        "angle": "ADBE Angle Control",
        "color": "ADBE Color Control",
        "point": "ADBE Point Control",
        "layer": "ADBE Layer Control"
    };

    var MASTER_COMMENT_TAG = "vac34_MASTER_LAYER_v1";

    function ControllerTransaction(targetLayer, recipe) {
        this.targetLayer = targetLayer;
        this.recipe = recipe;
        this.reusedEffects = [];
        this.newEffects = [];
        this.modifiedValues = [];
        this.failedOperations = [];
        this.controls = {};
        this.rolledBack = false;
        this.committed = false;
    }

    ControllerTransaction.prototype.setup = function(values) {
        if (!this.targetLayer || !this.recipe || !this.recipe.parameters) {
            this.failedOperations.push("Invalid target layer or recipe.");
            return false;
        }

        var effectsGroup = this.targetLayer.property("ADBE Effect Parade") || this.targetLayer.property("Effects");
        if (!effectsGroup) {
            this.failedOperations.push("Layer lacks Effects group.");
            return false;
        }

        var prefix = vac34_ControllerManager.getEffectPrefixForRecipe(this.recipe);

        for (var i = 0; i < this.recipe.parameters.length; i++) {
            var param = this.recipe.parameters[i];
            var effectName = prefix + " — " + param.name;
            var expectedMatch = MATCH_NAMES[param.type.toLowerCase()] || "ADBE Slider Control";

            var existing = effectsGroup.property(effectName);
            var hadExisting = !!existing;
            var originalVal = undefined;
            if (existing) {
                var valProp = existing.property(1);
                originalVal = (valProp && typeof valProp.value !== "undefined") ? valProp.value : undefined;
            }

            var eff = vac34_ControllerManager.ensureParameterControl(this.targetLayer, this.recipe, param);
            if (!eff) {
                this.failedOperations.push("Failed to ensure parameter control for " + param.name);
                return false;
            }

            if (hadExisting) {
                this.reusedEffects.push({
                    effect: eff,
                    paramId: param.id,
                    originalValue: originalVal
                });
                if (values && values[param.id] !== undefined) {
                    this.modifiedValues.push({
                        effect: eff,
                        previousValue: originalVal
                    });
                    var pProp = eff.property(1);
                    if (pProp) {
                        try { pProp.setValue(values[param.id]); } catch (e) {}
                    }
                }
            } else {
                this.newEffects.push(eff);
                if (values && values[param.id] !== undefined) {
                    var nProp = eff.property(1);
                    if (nProp) {
                        try { nProp.setValue(values[param.id]); } catch (e) {}
                    }
                }
            }
            this.controls[param.id] = eff;
        }

        return true;
    };

    ControllerTransaction.prototype.rollback = function() {
        if (this.rolledBack) return;
        this.rolledBack = true;

        // 1. Remove newly created controls only
        for (var i = this.newEffects.length - 1; i >= 0; i--) {
            try {
                this.newEffects[i].remove();
            } catch (e) {
                this.failedOperations.push("Failed to remove newly created control: " + e.message);
            }
        }

        // 2. Restore changed values on reused controls
        for (var j = 0; j < this.modifiedValues.length; j++) {
            try {
                var mv = this.modifiedValues[j];
                var valProp = mv.effect.property(1);
                if (valProp && mv.previousValue !== undefined) {
                    valProp.setValue(mv.previousValue);
                }
            } catch (e) {
                this.failedOperations.push("Failed to restore previous value on control: " + e.message);
            }
        }
    };

    ControllerTransaction.prototype.commit = function() {
        this.committed = true;
    };

    return {
        MATCH_NAMES: MATCH_NAMES,
        MASTER_COMMENT_TAG: MASTER_COMMENT_TAG,

        ControllerTransaction: ControllerTransaction,

        beginTransaction: function(targetLayer, recipe) {
            return new ControllerTransaction(targetLayer, recipe);
        },

        getOrCreateMasterLayer: function(comp) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!comp) return null;

            var baseName = vac34_Config.MASTER_LAYER_NAME;
            var exactMaster = null;
            var collisionFound = false;

            for (var i = 1; i <= comp.numLayers; i++) {
                var lyr = comp.layer(i);
                if (lyr && lyr.name) {
                    if (lyr.name === baseName) {
                        // Check identity: must be marked with master comment tag
                        var comment = lyr.comment || "";
                        if (comment.indexOf(MASTER_COMMENT_TAG) !== -1 || (lyr.nullLayer && lyr.guideLayer && comment === "")) {
                            if (!lyr.comment) {
                                try { lyr.comment = MASTER_COMMENT_TAG; } catch (e) {}
                            }
                            return lyr;
                        } else {
                            // Foreign user layer has name vac34_Master_Controls
                            collisionFound = true;
                        }
                    } else if (lyr.name.indexOf(baseName + "_") === 0) {
                        var c = lyr.comment || "";
                        if (c.indexOf(MASTER_COMMENT_TAG) !== -1) {
                            return lyr;
                        }
                    }
                }
            }

            // Create Master Null with collision avoidance
            try {
                var targetName = baseName;
                if (collisionFound) {
                    var counter = 1;
                    while (comp.layer(baseName + "_" + counter)) {
                        counter++;
                    }
                    targetName = baseName + "_" + counter;
                }

                var master = comp.layers.addNull();
                master.name = targetName;
                try { master.comment = MASTER_COMMENT_TAG; } catch (e) {}
                master.label = 13;
                master.guideLayer = true;
                master.moveToBeginning();
                return master;
            } catch (e) {
                return null;
            }
        },

        getEffectPrefixForRecipe: function(recipe) {
            return vac34_Config.EFFECT_PREFIX + recipe.displayName;
        },

        ensureParameterControl: function(targetLayer, recipe, param) {
            if (!targetLayer) return null;
            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return null;

            var effectName = this.getEffectPrefixForRecipe(recipe) + " — " + param.name;
            var expectedMatch = MATCH_NAMES[param.type.toLowerCase()] || "ADBE Slider Control";

            // Check if already exists and verify matchName
            var existing = effectsGroup.property(effectName);
            if (existing) {
                if (existing.matchName === expectedMatch) {
                    return existing;
                }
                // Name collision with different matchName - cannot safely reuse
                return null;
            }

            try {
                if (effectsGroup.canAddProperty && !effectsGroup.canAddProperty(expectedMatch)) {
                    return null;
                }
                var newEffect = effectsGroup.addProperty(expectedMatch);
                if (newEffect) {
                    newEffect.name = effectName;
                    var valProp = newEffect.property(1);
                    if (valProp && param["default"] !== undefined) {
                        try {
                            valProp.setValue(param["default"]);
                        } catch (e) {}
                    }
                    return newEffect;
                }
            } catch (e) {
                return null;
            }
            return null;
        },

        setupRecipeControls: function(targetLayer, recipe, values) {
            if (!targetLayer || !recipe || !recipe.parameters) return null;
            var tx = new ControllerTransaction(targetLayer, recipe);
            var ok = tx.setup(values);
            if (!ok) {
                tx.rollback();
                return null;
            }
            var controls = tx.controls;
            controls._tx = tx;
            return controls;
        },

        updateParameterValue: function(targetLayer, recipe, paramId, value) {
            if (!targetLayer || !recipe) return false;
            var param = null;
            for (var i = 0; i < recipe.parameters.length; i++) {
                if (recipe.parameters[i].id === paramId) {
                    param = recipe.parameters[i];
                    break;
                }
            }
            if (!param) return false;

            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return false;

            var effectName = this.getEffectPrefixForRecipe(recipe) + " — " + param.name;
            var effect = effectsGroup.property(effectName);
            if (effect) {
                var valProp = effect.property(1);
                if (valProp) {
                    try {
                        valProp.setValue(value);
                        return true;
                    } catch (e) {
                        return false;
                    }
                }
            }
            return false;
        },

        removeRecipeControls: function(targetLayer, recipe) {
            if (!targetLayer || !recipe || !recipe.parameters) return 0;
            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return 0;

            var removed = 0;
            var prefix = this.getEffectPrefixForRecipe(recipe);

            // Exact owned-controller discovery: only remove controls that match known parameters
            var ownedNames = {};
            for (var p = 0; p < recipe.parameters.length; p++) {
                var expectedName = prefix + " — " + recipe.parameters[p].name;
                var expectedMatch = MATCH_NAMES[recipe.parameters[p].type.toLowerCase()] || "ADBE Slider Control";
                ownedNames[expectedName] = expectedMatch;
            }

            for (var i = effectsGroup.numProperties; i >= 1; i--) {
                var eff = effectsGroup.property(i);
                if (eff && eff.name && ownedNames.hasOwnProperty(eff.name)) {
                    var match = ownedNames[eff.name];
                    if (eff.matchName === match) {
                        eff.remove();
                        removed++;
                    }
                }
            }
            return removed;
        }
    };
})();
