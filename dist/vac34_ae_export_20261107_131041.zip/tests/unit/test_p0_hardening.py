#!/usr/bin/env python3
"""
vac34_AE P0 & P1 Hardening Unit Tests
Directly tests:
  - Foreign expression overwrite protection (byte-identical preservation)
  - Guaranteed Undo Group closure on exception
  - Safe JSON preset validation without code execution
  - 2D vs 3D vector adaptation
"""

import os
import unittest
import subprocess

WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestP0Hardening(unittest.TestCase):
    def test_foreign_expression_preservation_mock(self):
        """Regression Test A: Verify that foreign expression is preserved byte-identical."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');

        // Setup mock environment
        let undoDepth = 0;
        global.app = {
            project: { activeItem: null },
            beginUndoGroup: (n) => { undoDepth++; },
            endUndoGroup: () => { undoDepth--; }
        };

        const targetProp = {
            name: "Position",
            expression: "value + [10, 20]; // User custom foreign expression",
            canSetExpression: true,
            propertyValueType: 2 // 2D_SPATIAL
        };

        const mockLayer = {
            name: "Test Layer",
            selectedProperties: [targetProp],
            property: (p) => {
                if (p === "Transform") return { property: (p2) => (p2 === "Position" ? targetProp : null) };
                if (p === "Effects" || p === "ADBE Effect Parade") return null;
                return null;
            }
        };

        const originalExpr = targetProp.expression;

        // Execute bundle passing global as thisObj
        new Function('thisObj', bundle)(global);

        // Run checkApplication
        const diag = global.vac34_Diagnostics.checkApplication(
            { name: "Comp", selectedLayers: [mockLayer] },
            [mockLayer],
            global.vac34_RecipeRegistry.getRecipeById("position.wiggle.smooth")
        );

        if (diag.canApply !== false) {
            console.error("FAIL: diag.canApply should be false for foreign expression");
            process.exit(1);
        }

        if (diag.conflictedLayers.length !== 1) {
            console.error("FAIL: foreign expression layer was not recorded in conflictedLayers");
            process.exit(2);
        }

        // Run applyRecipe
        const res = global.vac34_Engine.applyRecipe(
            { name: "Comp", selectedLayers: [mockLayer] },
            [mockLayer],
            global.vac34_RecipeRegistry.getRecipeById("position.wiggle.smooth"),
            { freq: 2, amt_x: 20, amt_y: 20 },
            false
        );

        if (targetProp.expression !== originalExpr) {
            console.error("P0 VIOLATION: Foreign expression was modified!");
            process.exit(3);
        }

        if (res.conflictCount !== 1) {
            console.error("FAIL: res.conflictCount should be 1");
            process.exit(4);
        }

        console.log("PASS: Foreign expression preserved byte-identical.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Foreign expression test failed:\n{proc.stderr}\n{proc.stdout}")

    def test_undo_group_closed_on_exception(self):
        """Regression Test B: Guaranteed Undo Group closure on exception."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');

        let beginCount = 0;
        let endCount = 0;
        global.app = {
            project: { activeItem: null },
            beginUndoGroup: (n) => { beginCount++; },
            endUndoGroup: () => { endCount++; }
        };

        const badLayer = {
            name: "Failing Layer",
            property: () => { throw new Error("Simulated AE DOM crash"); }
        };

        new Function('thisObj', bundle)(global);

        try {
            global.vac34_Engine.applyRecipe(
                { name: "Comp", selectedLayers: [badLayer] },
                [badLayer],
                global.vac34_RecipeRegistry.getRecipeById("scale.uniform.breathing"),
                {},
                false
            );
        } catch (e) {
            // Expected
        }

        if (global.vac34_AEDom.getUndoDepth() !== 0) {
            console.error("P0 VIOLATION: Undo depth is " + global.vac34_AEDom.getUndoDepth() + " (not closed!)");
            process.exit(1);
        }

        console.log("PASS: Undo group closed cleanly.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Undo group test failed:\n{proc.stderr}\n{proc.stdout}")

    def test_preset_safety_no_arbitrary_code_exec(self):
        """Regression Test H: Ensure presets do not execute arbitrary JavaScript."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');
        new Function('thisObj', bundle)(global);

        global.codeExecuted = false;
        // Malicious JSON string attempting function execution
        const malicious = '{"recipeId": "scale.uniform.breathing", "evil": (function(){ global.codeExecuted = true; return 1; })()}';

        // Mock File constructor
        global.Folder = function() { return { exists: true, create: () => {} }; };
        global.Folder.userData = { fsName: "." };
        global.File = function() {
            return {
                exists: true,
                open: () => {},
                read: () => malicious,
                close: () => {}
            };
        };

        try {
            global.vac34_PresetManager.loadPreset("malicious_preset");
        } catch (e) {
            // Safe rejection
        }

        if (global.codeExecuted) {
            console.error("P1 SECURITY VIOLATION: Arbitrary code executed during preset load!");
            process.exit(1);
        }

        console.log("PASS: Malicious preset rejected safely.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Preset safety test failed:\n{proc.stderr}\n{proc.stdout}")

    def test_parse_json_strict_direct(self):
        """Regression Test I: Verify pure-JS parseJSONStrict directly parses valid JSON and rejects invalid without eval."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');
        new Function('thisObj', bundle)(global);

        const parse = global.vac34_PresetManager.parseJSONStrict;

        // Valid JSON tests
        const validSamples = [
            '{"recipeId": "position.wiggle.smooth", "parameters": {"freq": 2.5, "amt_x": -10, "enable": true, "text": "hello world"}}',
            '{"arr": [1, 2, -3.14, true, false, null, "item"], "nested": {"k": "v"}}',
            '{}',
            '[]',
            '123.45',
            '"simple string"'
        ];

        for (let s of validSamples) {
            try {
                const parsed = parse(s);
                if (parsed === undefined) {
                    console.error("FAIL: parse returned undefined for valid JSON: " + s);
                    process.exit(1);
                }
            } catch (e) {
                console.error("FAIL: parse threw error on valid JSON: " + s + " -> " + e.message);
                process.exit(2);
            }
        }

        // Invalid JSON tests
        const invalidSamples = [
            '{"trailing": 1} trailing_garbage',
            '{"unclosed": "string',
            '{badKey: 123}',
            '{"val": [1, 2, }',
            'function() { return 1; }',
            'undefined'
        ];

        for (let bad of invalidSamples) {
            let threw = false;
            try {
                parse(bad);
            } catch (e) {
                threw = true;
            }
            if (!threw) {
                console.error("FAIL: parse failed to reject invalid JSON: " + bad);
                process.exit(3);
            }
        }

        console.log("PASS: parseJSONStrict validated.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"parseJSONStrict test failed:\n{proc.stderr}\n{proc.stdout}")

    def test_recipe_conflict_prevention(self):
        """Regression Test J: Prevent cross-recipe conflict overwrite."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');
        new Function('thisObj', bundle)(global);

        let undoDepth = 0;
        global.app = {
            project: { activeItem: null },
            beginUndoGroup: () => { undoDepth++; },
            endUndoGroup: () => { undoDepth--; }
        };

        const existingExpr = "// [vac34:scale.uniform.breathing]\\n// Parameters: freq=2\\nvalue + [10, 10];";
        const targetProp = {
            name: "Scale",
            expression: existingExpr,
            canSetExpression: true,
            propertyValueType: 2
        };

        const mockLayer = {
            name: "Layer With Breathing",
            selectedProperties: [targetProp],
            property: (p) => {
                if (p === "Transform") return { property: (p2) => (p2 === "Scale" ? targetProp : null) };
                return null;
            }
        };

        // Attempt to check and apply a different recipe to this property
        const recipeA = global.vac34_RecipeRegistry.getRecipeById("scale.uniform.breathing");
        const recipeB = global.vac34_RecipeRegistry.getRecipeById("position.wiggle.smooth");

        // Verify checkApplication detects conflict if recipe does not match
        // Let's create a recipe that also targets Scale but has different id
        const fakeConflictingRecipe = {
            id: "scale.other.recipe",
            displayName: "Other Scale Recipe",
            targetProperty: "Transform.Scale",
            parameters: []
        };

        const diag = global.vac34_Diagnostics.checkApplication(
            { name: "Comp", selectedLayers: [mockLayer] },
            [mockLayer],
            fakeConflictingRecipe
        );

        if (diag.canApply !== false) {
            console.error("FAIL: diag.canApply should be false for conflicting recipe on same property");
            process.exit(1);
        }

        if (diag.conflictedLayers.length !== 1) {
            console.error("FAIL: conflicting layer was not added to conflictedLayers");
            process.exit(2);
        }

        // Now test applyRecipe rejects it
        const res = global.vac34_Engine.applyRecipe(
            { name: "Comp", selectedLayers: [mockLayer] },
            [mockLayer],
            fakeConflictingRecipe,
            {},
            false
        );

        if (targetProp.expression !== existingExpr) {
            console.error("FAIL: Existing expression was modified despite conflict!");
            process.exit(3);
        }

        if (res.conflictCount !== 1 || res.appliedCount !== 0) {
            console.error("FAIL: Expected conflictCount: 1, appliedCount: 0; got: " + JSON.stringify(res));
            process.exit(4);
        }

        console.log("PASS: Recipe conflict successfully prevented.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Recipe conflict test failed:\n{proc.stderr}\n{proc.stdout}")

    def test_controller_creation_failure_rollback(self):
        """Regression Test K: Failure during controller creation rolls back and aborts expression assignment."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');
        new Function('thisObj', bundle)(global);

        global.app = {
            project: { activeItem: null },
            beginUndoGroup: () => {},
            endUndoGroup: () => {}
        };

        const targetProp = {
            name: "Position",
            expression: "",
            canSetExpression: true,
            propertyValueType: 2
        };

        const removedEffects = [];
        const effectsGroup = {
            property: (n) => null,
            canAddProperty: (m) => true,
            addProperty: (m) => {
                // Return an effect, but simulate error on second effect or throw
                return {
                    name: "Effect",
                    property: () => ({ setValue: () => {} }),
                    remove: function() { removedEffects.push(this.name); }
                };
            }
        };

        // Override ensureParameterControl to fail on second parameter
        const origEnsure = global.vac34_ControllerManager.ensureParameterControl;
        let callCount = 0;
        global.vac34_ControllerManager.ensureParameterControl = function(targetLayer, recipe, param) {
            callCount++;
            if (callCount === 2) {
                // Simulate failure on second param
                return null;
            }
            return {
                name: "PartialEffect",
                property: () => ({ setValue: () => {} }),
                remove: function() { removedEffects.push("PartialEffect"); }
            };
        };

        const mockLayer = {
            name: "Layer With Failing Controls",
            selectedProperties: [targetProp],
            property: (p) => {
                if (p === "Transform") return { property: (p2) => (p2 === "Position" ? targetProp : null) };
                if (p === "ADBE Effect Parade" || p === "Effects") return effectsGroup;
                return null;
            }
        };

        const recipe = global.vac34_RecipeRegistry.getRecipeById("position.wiggle.smooth"); // has freq, amt_x, amt_y

        const res = global.vac34_Engine.applyRecipe(
            { name: "Comp", selectedLayers: [mockLayer] },
            [mockLayer],
            recipe,
            { freq: 2, amt_x: 10, amt_y: 10 },
            false
        );

        if (targetProp.expression !== "") {
            console.error("FAIL: Expression was applied despite controller failure!");
            process.exit(1);
        }

        if (res.appliedCount !== 0) {
            console.error("FAIL: appliedCount should be 0; got: " + res.appliedCount);
            process.exit(2);
        }

        if (removedEffects.length !== 1) {
            console.error("FAIL: Partial effects were not rolled back/removed!");
            process.exit(3);
        }

        console.log("PASS: Controller failure cleanly rolled back.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Controller rollback test failed:\n{proc.stderr}\n{proc.stdout}")

if __name__ == "__main__":
    unittest.main()
