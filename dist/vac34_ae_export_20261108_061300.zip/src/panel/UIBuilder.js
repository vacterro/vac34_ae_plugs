/*
 * vac34_AE — Master Expressions Studio
 * UIBuilder: Professional ScriptUI Dockable Panel Interface with Cross-Category Preset Loading
 */

var vac34_UIBuilder = (function() {
    function safeRemoveChildren(container) {
        if (!container || !container.children) return;
        var guard = 500;
        while (container.children.length > 0 && guard-- > 0) {
            var prevLen = container.children.length;
            try {
                if (typeof container.remove === "function") {
                    container.remove(container.children[0]);
                }
            } catch (e) {}
            if (container.children.length >= prevLen) {
                if (typeof container.children.shift === "function") {
                    container.children.shift();
                } else {
                    try {
                        container.remove(0);
                    } catch (e2) {}
                    if (container.children.length >= prevLen) {
                        break;
                    }
                }
            }
        }
    }

    return {
        build: function(thisObj) {
            var win = null;
            try {
                if (typeof vac34_Diagnostics !== "undefined") {
                    vac34_Diagnostics.setStartupStage("2. Modules initialized");
                    vac34_Diagnostics.setStartupStage("3. UI container created");
                }
                var isDocked = (typeof Panel !== "undefined" && (thisObj instanceof Panel)) || (thisObj && thisObj.type === "panel");
                win = isDocked ? thisObj : new Window("palette", vac34_Config.PRODUCT_TITLE, undefined, { resizeable: true });
                if (isDocked && win.children && win.children.length > 0) {
                    safeRemoveChildren(win);
                }
                win.orientation = "column";
                win.alignChildren = ["fill", "top"];
                win.spacing = 6;
                win.margins = 10;
                try {
                    win.minimumSize = [200, 260];
                } catch (eMin) {}

                if (typeof vac34_Diagnostics !== "undefined") {
                    vac34_Diagnostics.setStartupStage("4. Controls created");
                }

                // --- HEADER ---
            var headerGroup = win.add("group");
            headerGroup.orientation = "row";
            headerGroup.alignChildren = ["fill", "center"];

            var titleLbl = headerGroup.add("statictext", undefined, "⚡ " + vac34_Config.PRODUCT_NAME + " v" + vac34_Config.VERSION + " (" + vac34_Config.BUILD_ID + ")");
            try {
                titleLbl.graphics.font = ScriptUI.newFont("Verdana", "BOLD", 12);
            } catch (e) {}

            var compStatusLbl = headerGroup.add("statictext", undefined, "No Comp");
            compStatusLbl.alignment = ["right", "center"];

            var btnRefresh = headerGroup.add("button", undefined, "⟳");
            btnRefresh.preferredSize = [24, 22];

            // --- TARGET SELECTION & PREVIEW ---
            var targetGroup = win.add("group");
            targetGroup.orientation = "column";
            targetGroup.alignChildren = ["fill", "top"];
            targetGroup.spacing = 2;

            var targetRow = targetGroup.add("group");
            targetRow.orientation = "row";
            targetRow.alignChildren = ["fill", "center"];

            var targetModeDrop = targetRow.add("dropdownlist", undefined, ["Target: Auto (Detect)", "Target: Selected Property", "Target: Recipe Default"]);
            targetModeDrop.selection = 0;
            targetModeDrop.preferredSize = [180, 22];

            var targetPreviewLbl = targetGroup.add("statictext", undefined, "Target: Auto (Detecting...)");
            try {
                targetPreviewLbl.graphics.font = ScriptUI.newFont("Verdana", "REGULAR", 10);
            } catch (e) {}

            // --- SEARCH & FILTER ---
            var filterGroup = win.add("group");
            filterGroup.orientation = "row";
            filterGroup.alignChildren = ["fill", "center"];

            var searchInput = filterGroup.add("edittext", undefined, "");
            searchInput.preferredSize = [130, 22];
            searchInput.helpTip = "Search behaviors...";

            var catDropdown = filterGroup.add("dropdownlist", undefined, vac34_RecipeRegistry.getCategories());
            catDropdown.selection = 0;
            catDropdown.preferredSize = [140, 22];

            // --- RECIPE LIST ---
            var listGroup = win.add("group");
            listGroup.orientation = "column";
            listGroup.alignChildren = ["fill", "top"];

            var recipeList = listGroup.add("listbox", undefined, []);
            recipeList.preferredSize = [-1, 110];

            var descLbl = listGroup.add("statictext", undefined, "", { multiline: true });
            descLbl.preferredSize = [-1, 28];

            // --- AUDIO ROUTING PANEL ---
            var audioGroup = win.add("panel", undefined, "Audio Source Link");
            audioGroup.orientation = "row";
            audioGroup.alignChildren = ["fill", "center"];
            audioGroup.margins = 6;

            var audioLyrLbl = audioGroup.add("statictext", undefined, "Layer:");
            var audioLayerDrop = audioGroup.add("dropdownlist", undefined, ["Audio Amplitude"]);
            audioLayerDrop.selection = 0;
            audioLayerDrop.preferredSize = [130, 20];

            var audioChanLbl = audioGroup.add("statictext", undefined, "Channel:");
            var audioChanDrop = audioGroup.add("dropdownlist", undefined, ["Both Channels", "Left Channel", "Right Channel"]);
            audioChanDrop.selection = 0;
            audioChanDrop.preferredSize = [110, 20];

            // --- CONTROLLER MODE ---
            var modeGroup = win.add("group");
            modeGroup.orientation = "row";
            modeGroup.alignChildren = ["left", "center"];

            var rbPerLayer = modeGroup.add("radiobutton", undefined, "Per-Layer Controls");
            rbPerLayer.value = true;
            var rbMaster = modeGroup.add("radiobutton", undefined, "Shared Master Null");

            // --- PARAMETER EDITOR PANEL ---
            var paramPanel = win.add("panel", undefined, "Parameters");
            paramPanel.orientation = "column";
            paramPanel.alignChildren = ["fill", "top"];
            paramPanel.margins = 8;
            paramPanel.preferredSize = [-1, 140];

            // --- ACTIONS BAR ---
            var actionGroup = win.add("group");
            actionGroup.orientation = "row";
            actionGroup.alignChildren = ["fill", "center"];

            var btnApply = actionGroup.add("button", undefined, "▶ Apply Behavior");
            btnApply.preferredSize = [-1, 28];

            var btnUpdate = actionGroup.add("button", undefined, "Update");
            btnUpdate.preferredSize = [65, 28];

            var btnRemove = actionGroup.add("button", undefined, "Remove");
            btnRemove.preferredSize = [65, 28];

            // Presets row
            var presetGroup = win.add("group");
            presetGroup.orientation = "row";
            presetGroup.alignChildren = ["fill", "center"];

            var btnSavePreset = presetGroup.add("button", undefined, "Save Preset");
            var btnLoadPreset = presetGroup.add("button", undefined, "Load Preset");

            // --- DIAGNOSTICS & STATUS ---
            var statusBox = win.add("edittext", undefined, "Ready.", { multiline: true, readonly: true });
            statusBox.preferredSize = [-1, 40];

            // -------------------------------------------------------------
            // UI STATE & CONTROLLER LOGIC
            // -------------------------------------------------------------
            var currentRecipes = [];
            var currentSelectedRecipe = null;
            var paramControlMap = {};
            var _selectedAudioName = null;

            function getSelectedTargetMode() {
                if (!targetModeDrop || !targetModeDrop.selection) return "AUTO";
                var idx = targetModeDrop.selection.index;
                if (idx === 1) return "SELECTED_PROPERTY";
                if (idx === 2) return "RECIPE_DEFAULT";
                return "AUTO";
            }

            function updateTargetPreview() {
                if (typeof vac34_TargetResolver === "undefined") return;
                var comp = vac34_AEDom.getActiveComp();
                var layers = vac34_AEDom.getSelectedLayers(comp);
                var mode = getSelectedTargetMode();
                var summary = vac34_TargetResolver.getPreviewSummary(comp, layers, currentSelectedRecipe, mode);
                targetPreviewLbl.text = summary;
            }

            function refreshCompStatus() {
                var comp = vac34_AEDom.getActiveComp();
                if (comp) {
                    var selLayers = vac34_AEDom.getSelectedLayers(comp);
                    compStatusLbl.text = comp.name + " (" + selLayers.length + " sel)";
                } else {
                    compStatusLbl.text = "No Active Comp";
                }

                var currentSelectionName = (audioLayerDrop.selection) ? audioLayerDrop.selection.text : _selectedAudioName;
                if (audioLayerDrop.selection) {
                    _selectedAudioName = audioLayerDrop.selection.text;
                }

                var audioSources = vac34_AudioEngine.findAudioLayers(comp);
                if (typeof audioLayerDrop.removeAll === "function") {
                    audioLayerDrop.removeAll();
                }

                var matchedIdx = -1;
                if (audioSources.length > 0) {
                    for (var i = 0; i < audioSources.length; i++) {
                        audioLayerDrop.add("item", audioSources[i].name);
                        if (currentSelectionName && audioSources[i].name === currentSelectionName && matchedIdx === -1) {
                            matchedIdx = i;
                        }
                    }
                } else {
                    audioLayerDrop.add("item", vac34_Config.AUDIO_LAYER_NAME);
                    if (currentSelectionName === vac34_Config.AUDIO_LAYER_NAME) {
                        matchedIdx = 0;
                    }
                }

                if (matchedIdx !== -1) {
                    audioLayerDrop.selection = matchedIdx;
                } else if (currentSelectionName && currentSelectionName !== vac34_Config.AUDIO_LAYER_NAME) {
                    // Previously selected audio source is no longer available in comp
                    audioLayerDrop.selection = null;
                } else if (audioLayerDrop.items && audioLayerDrop.items.length > 0) {
                    audioLayerDrop.selection = 0;
                }

                updateTargetPreview();
            }

            function refreshRecipeList() {
                var selCat = (catDropdown.selection) ? catDropdown.selection.text : "All";
                var query = searchInput.text;
                currentRecipes = vac34_RecipeRegistry.filterRecipes(selCat, query);

                if (typeof recipeList.removeAll === "function") {
                    recipeList.removeAll();
                }
                for (var i = 0; i < currentRecipes.length; i++) {
                    recipeList.add("item", currentRecipes[i].displayName);
                }

                if (currentRecipes.length > 0) {
                    setAuthoritativeSelection(0);
                } else {
                    setAuthoritativeSelection(null);
                }
            }

            function clearParamPanel() {
                safeRemoveChildren(paramPanel);
                paramControlMap = {};
                if (paramPanel.layout) paramPanel.layout.layout(true);
                if (win && win.layout) {
                    win.layout.layout(true);
                    win.layout.resize();
                }
            }

            function renderParameters(recipe, customValues) {
                clearParamPanel();
                if (!recipe || !recipe.parameters || recipe.parameters.length === 0) {
                    paramPanel.add("statictext", undefined, "No configurable parameters for this behavior.");
                    if (paramPanel.layout) paramPanel.layout.layout(true);
                    if (win && win.layout) {
                        win.layout.layout(true);
                        win.layout.resize();
                    }
                    return;
                }

                for (var i = 0; i < recipe.parameters.length; i++) {
                    (function(p) {
                        var row = paramPanel.add("group");
                        row.orientation = "row";
                        row.alignChildren = ["fill", "center"];
                        row.spacing = 4;

                        var nameLbl = row.add("statictext", undefined, p.name + ":");
                        nameLbl.preferredSize = [95, 20];

                        var defaultVal = (p["default"] !== undefined) ? p["default"] : 0;
                        var initialVal = (customValues && customValues[p.id] !== undefined) ? customValues[p.id] : defaultVal;
                        var minVal = (p.min !== undefined) ? p.min : 0;
                        var maxVal = (p.max !== undefined) ? p.max : 100;

                        var slider = row.add("slider", undefined, initialVal, minVal, maxVal);
                        slider.preferredSize = [120, 20];

                        var editbox = row.add("edittext", undefined, String(initialVal));
                        editbox.preferredSize = [45, 20];

                        var resetBtn = row.add("button", undefined, "↺");
                        resetBtn.preferredSize = [20, 20];
                        resetBtn.helpTip = "Reset to default (" + defaultVal + ")";

                        slider.onChanging = function() {
                            editbox.text = (p.type === "slider" && p.unit === "fps") ? Math.round(slider.value) : (Math.round(slider.value * 10) / 10);
                        };

                        editbox.onChange = function() {
                            var val = parseFloat(editbox.text);
                            if (!isNaN(val)) {
                                slider.value = val;
                            }
                        };

                        resetBtn.onClick = function() {
                            slider.value = defaultVal;
                            editbox.text = String(defaultVal);
                        };

                        paramControlMap[p.id] = {
                            param: p,
                            slider: slider,
                            editbox: editbox,
                            defaultVal: defaultVal
                        };
                    })(recipe.parameters[i]);
                }

                if (paramPanel.layout) paramPanel.layout.layout(true);
                if (win && win.layout) {
                    win.layout.layout(true);
                    win.layout.resize();
                }
            }

            function setAuthoritativeSelection(recipeOrIndex, customParamValues) {
                var recipe = null;
                var targetIndex = -1;

                if (typeof recipeOrIndex === "number") {
                    targetIndex = recipeOrIndex;
                    if (targetIndex >= 0 && targetIndex < currentRecipes.length) {
                        recipe = currentRecipes[targetIndex];
                    }
                } else if (recipeOrIndex && typeof recipeOrIndex === "object") {
                    recipe = recipeOrIndex;
                    for (var i = 0; i < currentRecipes.length; i++) {
                        if (currentRecipes[i].id === recipe.id) {
                            targetIndex = i;
                            break;
                        }
                    }
                    if (targetIndex === -1) {
                        if (catDropdown.selection && catDropdown.selection.index !== 0) {
                            catDropdown.selection = 0;
                        }
                        if (searchInput.text !== "") {
                            searchInput.text = "";
                        }
                        currentRecipes = vac34_RecipeRegistry.filterRecipes("All", "");
                        if (typeof recipeList.removeAll === "function") {
                            recipeList.removeAll();
                        }
                        for (var r = 0; r < currentRecipes.length; r++) {
                            recipeList.add("item", currentRecipes[r].displayName);
                            if (currentRecipes[r].id === recipe.id) {
                                targetIndex = r;
                            }
                        }
                    }
                }

                currentSelectedRecipe = recipe;

                if (recipe) {
                    if (targetIndex >= 0 && recipeList.items.length > targetIndex) {
                        recipeList.selection = targetIndex;
                    }
                    descLbl.text = recipe.description || "";
                    audioGroup.enabled = !!recipe.requiresAudio;
                    renderParameters(recipe, customParamValues);
                } else {
                    recipeList.selection = null;
                    descLbl.text = (currentRecipes.length === 0) ? "No matching behaviors found." : "";
                    clearParamPanel();
                }
                updateTargetPreview();
            }

            function collectCurrentParameterValues() {
                var values = {};
                for (var pId in paramControlMap) {
                    if (paramControlMap.hasOwnProperty(pId)) {
                        var ctrl = paramControlMap[pId];
                        var val = parseFloat(ctrl.editbox.text);
                        if (isNaN(val)) val = ctrl.slider.value;
                        values[pId] = val;
                    }
                }
                return values;
            }

            // --- EVENT WIRING ---
            btnRefresh.onClick = function() {
                refreshCompStatus();
            };

            targetModeDrop.onChange = function() {
                updateTargetPreview();
            };

            catDropdown.onChange = function() {
                refreshRecipeList();
            };

            searchInput.onChanging = function() {
                refreshRecipeList();
            };

            recipeList.onChange = function() {
                if (recipeList.selection) {
                    var idx = recipeList.selection.index;
                    setAuthoritativeSelection(idx);
                } else {
                    setAuthoritativeSelection(null);
                }
            };

            audioLayerDrop.onChange = function() {
                if (audioLayerDrop.selection) {
                    _selectedAudioName = audioLayerDrop.selection.text;
                }
            };

            btnApply.onClick = function() {
                refreshCompStatus();
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Please select a behavior first.";
                    return;
                }
                if (currentSelectedRecipe.requiresAudio && (!audioLayerDrop.selection || audioLayerDrop.selection.text === "")) {
                    var missingName = _selectedAudioName || "selected";
                    statusBox.text = "Error: Audio source '" + missingName + "' is missing or not found in composition.";
                    return;
                }
                var comp = vac34_AEDom.getActiveComp();
                var layers = vac34_AEDom.getSelectedLayers(comp);
                var pVals = collectCurrentParameterValues();
                var isMaster = rbMaster.value;
                var audioLyr = (audioLayerDrop.selection) ? audioLayerDrop.selection.text : vac34_Config.AUDIO_LAYER_NAME;
                var audioChan = (audioChanDrop.selection) ? audioChanDrop.selection.text : "Both Channels";
                var targetMode = getSelectedTargetMode();

                var res = vac34_Engine.applyRecipe(comp, layers, currentSelectedRecipe, pVals, isMaster, audioLyr, audioChan, targetMode);
                var msg = res.message;
                if (res.warnings && res.warnings.length > 0) {
                    msg += "\n" + res.warnings.join("\n");
                }
                statusBox.text = msg;
                updateTargetPreview();
            };

            btnUpdate.onClick = function() {
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Please select a behavior first.";
                    return;
                }
                var comp = vac34_AEDom.getActiveComp();
                if (!comp) {
                    statusBox.text = "Error: No active composition open in After Effects.";
                    return;
                }
                var layers = vac34_AEDom.getSelectedLayers(comp);
                if (!layers || layers.length === 0) {
                    statusBox.text = "Error: Please select at least one layer.";
                    return;
                }
                var pVals = collectCurrentParameterValues();
                var isMaster = rbMaster.value;

                var res = vac34_Engine.updateParameters(comp, layers, currentSelectedRecipe, pVals, isMaster);
                statusBox.text = res.message;
            };

            btnRemove.onClick = function() {
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Please select a behavior first.";
                    return;
                }
                var comp = vac34_AEDom.getActiveComp();
                if (!comp) {
                    statusBox.text = "Error: No active composition open in After Effects.";
                    return;
                }
                var layers = vac34_AEDom.getSelectedLayers(comp);
                var targetMode = getSelectedTargetMode();
                if (targetMode !== "SELECTED_PROPERTY" && (!layers || layers.length === 0)) {
                    statusBox.text = "Error: Please select at least one layer.";
                    return;
                }

                var res = vac34_Engine.removeRecipe(comp, layers, currentSelectedRecipe, null, targetMode);
                statusBox.text = res.message;
            };

            btnSavePreset.onClick = function() {
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Select a behavior before saving preset.";
                    return;
                }
                var name = prompt("Enter Preset Name:", currentSelectedRecipe.displayName + " Custom");
                if (name) {
                    var pVals = collectCurrentParameterValues();
                    var saved = vac34_PresetManager.savePreset(name, currentSelectedRecipe.id, pVals, rbMaster.value);
                    if (saved) {
                        statusBox.text = "Preset '" + name + "' saved successfully.";
                    } else {
                        statusBox.text = "Failed to save preset.";
                    }
                }
            };

            btnLoadPreset.onClick = function() {
                var presets = vac34_PresetManager.listPresets();
                if (presets.length === 0) {
                    statusBox.text = "No saved presets found in user folder.";
                    return;
                }
                var pWin = new Window("dialog", "Load Preset");
                pWin.orientation = "column";
                pWin.alignChildren = ["fill", "top"];
                var pList = pWin.add("listbox", undefined, presets);
                pList.selection = 0;
                pList.preferredSize = [200, 150];

                var pBtnRow = pWin.add("group");
                var btnOk = pBtnRow.add("button", undefined, "Load");
                var btnCancel = pBtnRow.add("button", undefined, "Cancel");

                btnOk.onClick = function() {
                    if (pList.selection) {
                        var pName = pList.selection.text;
                        var pData = vac34_PresetManager.loadPreset(pName);
                        if (pData) {
                            var rec = vac34_RecipeRegistry.getRecipeById(pData.recipeId);
                            if (rec) {
                                setAuthoritativeSelection(rec, pData.parameters);
                                rbMaster.value = !!pData.masterMode;
                                rbPerLayer.value = !pData.masterMode;
                                statusBox.text = "Loaded preset '" + pName + "' (" + rec.displayName + ").";
                            }
                        } else {
                            statusBox.text = "Error: Invalid or corrupted preset file.";
                        }
                    }
                    pWin.close();
                };
                btnCancel.onClick = function() { pWin.close(); };
                pWin.show();
            };

            win.onResizing = win.onResize = function() {
                if (this.layout) this.layout.resize();
            };

            win.setAuthoritativeSelection = setAuthoritativeSelection;
            win.getCurrentSelectedRecipe = function() { return currentSelectedRecipe; };
            win.getParamControlMap = function() { return paramControlMap; };

            if (typeof vac34_Diagnostics !== "undefined") {
                vac34_Diagnostics.setStartupStage("5. Recipes loaded");
            }
            refreshCompStatus();
            refreshRecipeList();

            if (typeof vac34_Diagnostics !== "undefined") {
                vac34_Diagnostics.setStartupStage("6. Initial layout complete");
            }
            if (win && win.layout) {
                win.layout.layout(true);
                win.layout.resize();
            }

            if (typeof vac34_Diagnostics !== "undefined") {
                vac34_Diagnostics.setStartupStage("7. Panel ready");
            }
            statusBox.text = "Ready.";

            return win;
        } catch (startupErr) {
            var failedStage = (typeof vac34_Diagnostics !== "undefined") ? vac34_Diagnostics.getCurrentStartupStage() : "3. UI container created";
            if (typeof vac34_Diagnostics !== "undefined") {
                vac34_Diagnostics.recordStartupError(failedStage, startupErr);
            }

            if (!win && thisObj && ((typeof Panel !== "undefined" && (thisObj instanceof Panel)) || (thisObj && thisObj.type === "panel"))) {
                win = thisObj;
            } else if (!win) {
                try {
                    win = new Window("palette", (typeof vac34_Config !== "undefined" ? vac34_Config.PRODUCT_NAME : "vac34_AE") + " [Diagnostic Mode]", undefined, { resizeable: true });
                } catch (wErr) {}
            }

            if (win) {
                try {
                    safeRemoveChildren(win);
                    win.orientation = "column";
                    win.alignChildren = ["fill", "top"];
                    win.spacing = 6;
                    win.margins = 10;

                    var errGroup = win.add("panel", undefined, "⚡ vac34_AE — Initialization Failure");
                    errGroup.orientation = "column";
                    errGroup.alignChildren = ["fill", "top"];
                    errGroup.margins = 10;
                    errGroup.spacing = 6;

                    var errTitle = errGroup.add("statictext", undefined, "Halted at: " + failedStage);
                    try {
                        errTitle.graphics.font = ScriptUI.newFont("Verdana", "BOLD", 11);
                    } catch (eFont) {}

                    var errMsg = (startupErr && (startupErr.message || startupErr.toString())) || "Unknown error";
                    var errLine = (startupErr && startupErr.line) ? ("\nLine: " + startupErr.line) : "";
                    var errDetails = errGroup.add("edittext", undefined, "Error: " + errMsg + errLine + "\nSee logs/startup_diagnostics.log for details.", { multiline: true, readonly: true });
                    errDetails.preferredSize = [-1, 75];

                    var retryBtn = errGroup.add("button", undefined, "Retry Startup");
                    retryBtn.onClick = function() {
                        try {
                            vac34_UIBuilder.build(thisObj);
                        } catch (reErr) {
                            if (typeof alert !== "undefined") alert("Retry failed: " + (reErr.message || reErr));
                        }
                    };

                    if (win.layout) {
                        win.layout.layout(true);
                        win.layout.resize();
                    }
                } catch (recErr) {}
            }
            throw startupErr;
        }
        }
    };
})();
