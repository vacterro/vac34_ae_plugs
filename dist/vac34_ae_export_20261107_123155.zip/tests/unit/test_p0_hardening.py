#!/usr/bin/env python3
"""
vac34_AE P0 & P1 Hardening Unit Tests
Directly tests:
  - Foreign expression overwrite protection (byte-identical preservation)
  - Guaranteed Undo Group closure on exception
  - Safe JSON preset validation without code execution
  - 2D vs 3D vector adaptation
"""

import os
import unittest
import subprocess

WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestP0Hardening(unittest.TestCase):
    def test_foreign_expression_preservation_mock(self):
        """Regression Test A: Verify that foreign expression is preserved byte-identical."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');

        // Setup mock environment
        let undoDepth = 0;
        global.app = {
            project: { activeItem: null },
            beginUndoGroup: (n) => { undoDepth++; },
            endUndoGroup: () => { undoDepth--; }
        };

        const targetProp = {
            name: "Position",
            expression: "value + [10, 20]; // User custom foreign expression",
            canSetExpression: true,
            propertyValueType: 2 // 2D_SPATIAL
        };

        const mockLayer = {
            name: "Test Layer",
            selectedProperties: [targetProp],
            property: (p) => {
                if (p === "Transform") return { property: (p2) => (p2 === "Position" ? targetProp : null) };
                if (p === "Effects" || p === "ADBE Effect Parade") return null;
                return null;
            }
        };

        const originalExpr = targetProp.expression;

        // Execute bundle passing global as thisObj
        new Function('thisObj', bundle)(global);

        // Run checkApplication
        const diag = global.vac34_Diagnostics.checkApplication(
            { name: "Comp", selectedLayers: [mockLayer] },
            [mockLayer],
            global.vac34_RecipeRegistry.getRecipeById("position.wiggle.smooth")
        );

        if (diag.canApply !== false) {
            console.error("FAIL: diag.canApply should be false for foreign expression");
            process.exit(1);
        }

        if (diag.conflictedLayers.length !== 1) {
            console.error("FAIL: foreign expression layer was not recorded in conflictedLayers");
            process.exit(2);
        }

        // Run applyRecipe
        const res = global.vac34_Engine.applyRecipe(
            { name: "Comp", selectedLayers: [mockLayer] },
            [mockLayer],
            global.vac34_RecipeRegistry.getRecipeById("position.wiggle.smooth"),
            { freq: 2, amt_x: 20, amt_y: 20 },
            false
        );

        if (targetProp.expression !== originalExpr) {
            console.error("P0 VIOLATION: Foreign expression was modified!");
            process.exit(3);
        }

        if (res.conflictCount !== 1) {
            console.error("FAIL: res.conflictCount should be 1");
            process.exit(4);
        }

        console.log("PASS: Foreign expression preserved byte-identical.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Foreign expression test failed:\n{proc.stderr}\n{proc.stdout}")

    def test_undo_group_closed_on_exception(self):
        """Regression Test B: Guaranteed Undo Group closure on exception."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');

        let beginCount = 0;
        let endCount = 0;
        global.app = {
            project: { activeItem: null },
            beginUndoGroup: (n) => { beginCount++; },
            endUndoGroup: () => { endCount++; }
        };

        const badLayer = {
            name: "Failing Layer",
            property: () => { throw new Error("Simulated AE DOM crash"); }
        };

        new Function('thisObj', bundle)(global);

        try {
            global.vac34_Engine.applyRecipe(
                { name: "Comp", selectedLayers: [badLayer] },
                [badLayer],
                global.vac34_RecipeRegistry.getRecipeById("scale.uniform.breathing"),
                {},
                false
            );
        } catch (e) {
            // Expected
        }

        if (global.vac34_AEDom.getUndoDepth() !== 0) {
            console.error("P0 VIOLATION: Undo depth is " + global.vac34_AEDom.getUndoDepth() + " (not closed!)");
            process.exit(1);
        }

        console.log("PASS: Undo group closed cleanly.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Undo group test failed:\n{proc.stderr}\n{proc.stdout}")

    def test_preset_safety_no_arbitrary_code_exec(self):
        """Regression Test H: Ensure presets do not execute arbitrary JavaScript."""
        node_script = """
        const fs = require('fs');
        const bundle = fs.readFileSync('dist/vac34_AE.jsx', 'utf8');
        new Function('thisObj', bundle)(global);

        global.codeExecuted = false;
        // Malicious JSON string attempting function execution
        const malicious = '{"recipeId": "scale.uniform.breathing", "evil": (function(){ global.codeExecuted = true; return 1; })()}';

        // Mock File constructor
        global.Folder = function() { return { exists: true, create: () => {} }; };
        global.Folder.userData = { fsName: "." };
        global.File = function() {
            return {
                exists: true,
                open: () => {},
                read: () => malicious,
                close: () => {}
            };
        };

        try {
            global.vac34_PresetManager.loadPreset("malicious_preset");
        } catch (e) {
            // Safe rejection
        }

        if (global.codeExecuted) {
            console.error("P1 SECURITY VIOLATION: Arbitrary code executed during preset load!");
            process.exit(1);
        }

        console.log("PASS: Malicious preset rejected safely.");
        process.exit(0);
        """
        proc = subprocess.run(["node", "-e", node_script], cwd=WORKSPACE_ROOT, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, f"Preset safety test failed:\n{proc.stderr}\n{proc.stdout}")

if __name__ == "__main__":
    unittest.main()
