/*
 * vac34_AE — Master Expressions Studio
 * Diagnostics: Strict compatibility checks, conflict enforcement & error reporting
 */

var vac34_Diagnostics = (function() {
    return {
        checkApplication: function(comp, layers, recipe, targetPropPath) {
            var result = {
                canApply: false,
                warnings: [],
                errors: [],
                compatibleLayers: [],
                conflictedLayers: [],
                incompatibleLayers: []
            };

            if (!comp) {
                result.errors.push("No active composition open in After Effects.");
                return result;
            }

            if (!layers || layers.length === 0) {
                result.errors.push("No layer selected. Select at least one layer.");
                return result;
            }

            if (!recipe) {
                result.errors.push("No recipe selected.");
                return result;
            }

            // Check Audio dependency
            if (recipe.requiresAudio) {
                var audioLayers = vac34_AudioEngine.findAudioLayers(comp);
                if (audioLayers.length === 0) {
                    result.warnings.push("Warning: No 'Audio Amplitude' layer found in active composition. (Expression will use fallback amplitude 0 until audio layer is created).");
                }
            }

            // Inspect selected layers
            for (var i = 0; i < layers.length; i++) {
                var lyr = layers[i];
                var propPath = targetPropPath || (recipe.targetProperties ? recipe.targetProperties[0] : null);

                if (!propPath || propPath === "Any.Property") {
                    // Check if property can be resolved
                    var candidateProp = null;
                    if (lyr.selectedProperties && lyr.selectedProperties.length > 0) {
                        for (var sp = 0; sp < lyr.selectedProperties.length; sp++) {
                            if (vac34_AEDom.canSetExpression(lyr.selectedProperties[sp])) {
                                candidateProp = lyr.selectedProperties[sp];
                                break;
                            }
                        }
                    }
                    if (!candidateProp) {
                        candidateProp = lyr.property("Transform") ? lyr.property("Transform").property("Position") : null;
                    }

                    if (!candidateProp || !vac34_AEDom.canSetExpression(candidateProp)) {
                        result.incompatibleLayers.push(lyr);
                        result.warnings.push("Layer '" + lyr.name + "' has no property capable of receiving expressions.");
                        continue;
                    }

                    // Check foreign expression
                    if (vac34_AEDom.hasForeignExpression(candidateProp)) {
                        result.conflictedLayers.push(lyr);
                        result.warnings.push("CONFLICT: Layer '" + lyr.name + "' has an existing foreign expression. Skipped to prevent overwrite.");
                        continue;
                    }

                    result.compatibleLayers.push(lyr);
                    continue;
                }

                var prop = vac34_AEDom.resolveProperty(lyr, propPath);
                if (!prop) {
                    result.incompatibleLayers.push(lyr);
                    result.warnings.push("Layer '" + lyr.name + "' lacks target property '" + propPath + "'.");
                    continue;
                }

                if (!vac34_AEDom.canSetExpression(prop)) {
                    result.incompatibleLayers.push(lyr);
                    result.warnings.push("Layer '" + lyr.name + "' property '" + propPath + "' cannot receive expressions.");
                    continue;
                }

                // STRICT P0: Foreign expression protection
                if (vac34_AEDom.hasForeignExpression(prop)) {
                    result.conflictedLayers.push(lyr);
                    result.warnings.push("CONFLICT: Layer '" + lyr.name + "' property '" + propPath + "' already has a custom expression. Refusing to overwrite (skipped).");
                    continue;
                }

                result.compatibleLayers.push(lyr);
            }

            if (result.compatibleLayers.length > 0) {
                result.canApply = true;
            } else {
                result.canApply = false;
                if (result.conflictedLayers.length > 0) {
                    result.errors.push("Application aborted: " + result.conflictedLayers.length + " layer(s) have existing foreign expressions.");
                } else {
                    result.errors.push("None of the selected layers have compatible properties for '" + recipe.displayName + "'.");
                }
            }

            return result;
        }
    };
})();
