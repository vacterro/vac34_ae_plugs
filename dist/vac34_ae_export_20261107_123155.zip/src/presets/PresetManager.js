/*
 * vac34_AE — Master Expressions Studio
 * PresetManager: Safe JSON parsing, schema validation & persistence
 */

var vac34_PresetManager = (function() {
    function getPresetFolder() {
        var userDataPath = (typeof Folder !== "undefined" && Folder.userData) ? Folder.userData.fsName : ".";
        var folder = new Folder(userDataPath + "/" + vac34_Config.PRESET_DIR_NAME);
        if (!folder.exists) {
            folder.create();
        }
        return folder;
    }

    // Safe, non-eval JSON parser for ExtendScript environments
    function safeParseJSON(str) {
        if (typeof JSON !== "undefined" && JSON.parse) {
            return JSON.parse(str);
        }

        // Strict character verification to prevent code execution
        // Only allow valid JSON tokens: whitespace, brackets, colons, commas, strings, numbers, true, false, null
        var sanitized = str.replace(/"(\\.|[^"\\])*"/g, '');
        if (/[\],:{}\s]/.test(sanitized.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                                .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                                .replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
            // Function constructor is safer than direct eval as it executes in separate scope without local leakage
            return (new Function("return " + str))();
        }
        throw new Error("Invalid or unsafe JSON format in preset file.");
    }

    return {
        getPresetFolder: getPresetFolder,

        listPresets: function() {
            var folder = getPresetFolder();
            if (!folder.exists) return [];
            var files = folder.getFiles("*.json");
            var names = [];
            for (var i = 0; i < files.length; i++) {
                var f = files[i];
                var name = decodeURI(f.name).replace(/\.json$/i, "");
                names.push(name);
            }
            return names;
        },

        savePreset: function(presetName, recipeId, paramValues, masterMode) {
            if (!presetName || !recipeId) return false;
            var cleanName = presetName.replace(/[^a-zA-Z0-9_\-\s]/g, "");
            if (cleanName === "") cleanName = "Preset";

            var folder = getPresetFolder();
            var file = new File(folder.fsName + "/" + cleanName + ".json");
            var data = {
                product: vac34_Config.PRODUCT_NAME,
                version: vac34_Config.VERSION,
                recipeId: recipeId,
                masterMode: !!masterMode,
                parameters: paramValues || {},
                createdAt: (new Date()).toUTCString()
            };

            try {
                file.encoding = "UTF-8";
                file.open("w");
                file.write(JSON.stringify(data));
                file.close();
                return true;
            } catch (e) {
                return false;
            }
        },

        loadPreset: function(presetName) {
            var cleanName = presetName.replace(/[^a-zA-Z0-9_\-\s]/g, "");
            var folder = getPresetFolder();
            var file = new File(folder.fsName + "/" + cleanName + ".json");
            if (!file.exists) return null;

            try {
                file.encoding = "UTF-8";
                file.open("r");
                var content = file.read();
                file.close();

                var data = safeParseJSON(content);
                // Validate schema
                if (!data || typeof data !== "object") return null;
                if (!data.recipeId || typeof data.recipeId !== "string") return null;
                if (!data.parameters || typeof data.parameters !== "object") return null;

                return data;
            } catch (e) {
                return null;
            }
        }
    };
})();
