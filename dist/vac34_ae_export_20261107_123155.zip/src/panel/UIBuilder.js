/*
 * vac34_AE — Master Expressions Studio
 * UIBuilder: Professional ScriptUI Dockable Panel Interface
 */

var vac34_UIBuilder = (function() {
    return {
        build: function(thisObj) {
            var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", vac34_Config.PRODUCT_TITLE, undefined, { resizeable: true });
            win.orientation = "column";
            win.alignChildren = ["fill", "top"];
            win.spacing = 6;
            win.margins = 10;

            // --- HEADER ---
            var headerGroup = win.add("group");
            headerGroup.orientation = "row";
            headerGroup.alignChildren = ["fill", "center"];

            var titleLbl = headerGroup.add("statictext", undefined, "⚡ " + vac34_Config.PRODUCT_NAME + " v" + vac34_Config.VERSION);
            titleLbl.graphics.font = ScriptUI.newFont("Verdana", "BOLD", 12);

            var compStatusLbl = headerGroup.add("statictext", undefined, "No Comp");
            compStatusLbl.alignment = ["right", "center"];

            var btnRefresh = headerGroup.add("button", undefined, "⟳");
            btnRefresh.preferredSize = [24, 22];

            // --- SEARCH & FILTER ---
            var filterGroup = win.add("group");
            filterGroup.orientation = "row";
            filterGroup.alignChildren = ["fill", "center"];

            var searchInput = filterGroup.add("edittext", undefined, "");
            searchInput.preferredSize = [130, 22];
            searchInput.helpTip = "Search behaviors...";

            var catDropdown = filterGroup.add("dropdownlist", undefined, vac34_RecipeRegistry.getCategories());
            catDropdown.selection = 0;
            catDropdown.preferredSize = [140, 22];

            // --- RECIPE LIST ---
            var listGroup = win.add("group");
            listGroup.orientation = "column";
            listGroup.alignChildren = ["fill", "top"];

            var recipeList = listGroup.add("listbox", undefined, []);
            recipeList.preferredSize = [-1, 110];

            var descLbl = listGroup.add("statictext", undefined, "", { multiline: true });
            descLbl.preferredSize = [-1, 28];

            // --- AUDIO ROUTING PANEL ---
            var audioGroup = win.add("panel", undefined, "Audio Source Link");
            audioGroup.orientation = "row";
            audioGroup.alignChildren = ["fill", "center"];
            audioGroup.margins = 6;

            var audioLyrLbl = audioGroup.add("statictext", undefined, "Layer:");
            var audioLayerDrop = audioGroup.add("dropdownlist", undefined, ["Audio Amplitude"]);
            audioLayerDrop.selection = 0;
            audioLayerDrop.preferredSize = [130, 20];

            var audioChanLbl = audioGroup.add("statictext", undefined, "Channel:");
            var audioChanDrop = audioGroup.add("dropdownlist", undefined, ["Both Channels", "Left Channel", "Right Channel"]);
            audioChanDrop.selection = 0;
            audioChanDrop.preferredSize = [110, 20];

            // --- CONTROLLER MODE ---
            var modeGroup = win.add("group");
            modeGroup.orientation = "row";
            modeGroup.alignChildren = ["left", "center"];

            var rbPerLayer = modeGroup.add("radiobutton", undefined, "Per-Layer Controls");
            rbPerLayer.value = true;
            var rbMaster = modeGroup.add("radiobutton", undefined, "Shared Master Null");

            // --- PARAMETER EDITOR PANEL ---
            var paramPanel = win.add("panel", undefined, "Parameters");
            paramPanel.orientation = "column";
            paramPanel.alignChildren = ["fill", "top"];
            paramPanel.margins = 8;
            paramPanel.preferredSize = [-1, 140];

            // --- ACTIONS BAR ---
            var actionGroup = win.add("group");
            actionGroup.orientation = "row";
            actionGroup.alignChildren = ["fill", "center"];

            var btnApply = actionGroup.add("button", undefined, "▶ Apply Behavior");
            btnApply.preferredSize = [-1, 28];

            var btnUpdate = actionGroup.add("button", undefined, "Update");
            btnUpdate.preferredSize = [65, 28];

            var btnRemove = actionGroup.add("button", undefined, "Remove");
            btnRemove.preferredSize = [65, 28];

            // Presets row
            var presetGroup = win.add("group");
            presetGroup.orientation = "row";
            presetGroup.alignChildren = ["fill", "center"];

            var btnSavePreset = presetGroup.add("button", undefined, "Save Preset");
            var btnLoadPreset = presetGroup.add("button", undefined, "Load Preset");

            // --- DIAGNOSTICS & STATUS ---
            var statusBox = win.add("edittext", undefined, "Ready.", { multiline: true, readonly: true });
            statusBox.preferredSize = [-1, 40];

            // -------------------------------------------------------------
            // UI STATE & CONTROLLER LOGIC
            // -------------------------------------------------------------
            var currentRecipes = [];
            var currentSelectedRecipe = null;
            var paramControlMap = {}; // paramId -> { slider, editbox, defaultVal }

            function refreshCompStatus() {
                var comp = vac34_AEDom.getActiveComp();
                if (comp) {
                    var selLayers = vac34_AEDom.getSelectedLayers(comp);
                    compStatusLbl.text = comp.name + " (" + selLayers.length + " sel)";
                } else {
                    compStatusLbl.text = "No Active Comp";
                }

                // Refresh audio dropdown
                var audioSources = vac34_AudioEngine.findAudioLayers(comp);
                audioLayerDrop.removeAll();
                if (audioSources.length > 0) {
                    for (var i = 0; i < audioSources.length; i++) {
                        audioLayerDrop.add("item", audioSources[i].name);
                    }
                } else {
                    audioLayerDrop.add("item", vac34_Config.AUDIO_LAYER_NAME);
                }
                audioLayerDrop.selection = 0;
            }

            function refreshRecipeList() {
                var selCat = (catDropdown.selection) ? catDropdown.selection.text : "All";
                var query = searchInput.text;
                currentRecipes = vac34_RecipeRegistry.filterRecipes(selCat, query);

                recipeList.removeAll();
                for (var i = 0; i < currentRecipes.length; i++) {
                    recipeList.add("item", currentRecipes[i].displayName);
                }

                if (currentRecipes.length > 0) {
                    recipeList.selection = 0;
                } else {
                    descLbl.text = "No matching behaviors found.";
                    clearParamPanel();
                }
            }

            function clearParamPanel() {
                while (paramPanel.children.length > 0) {
                    paramPanel.remove(paramPanel.children[0]);
                }
                paramControlMap = {};
                paramPanel.layout.layout(true);
            }

            function renderParameters(recipe) {
                clearParamPanel();
                if (!recipe || !recipe.parameters || recipe.parameters.length === 0) {
                    var emptyLbl = paramPanel.add("statictext", undefined, "No configurable parameters for this behavior.");
                    paramPanel.layout.layout(true);
                    return;
                }

                for (var i = 0; i < recipe.parameters.length; i++) {
                    (function(p) {
                        var row = paramPanel.add("group");
                        row.orientation = "row";
                        row.alignChildren = ["fill", "center"];
                        row.spacing = 4;

                        var nameLbl = row.add("statictext", undefined, p.name + ":");
                        nameLbl.preferredSize = [95, 20];

                        var defaultVal = (p["default"] !== undefined) ? p["default"] : 0;
                        var minVal = (p.min !== undefined) ? p.min : 0;
                        var maxVal = (p.max !== undefined) ? p.max : 100;

                        var slider = row.add("slider", undefined, defaultVal, minVal, maxVal);
                        slider.preferredSize = [120, 20];

                        var editbox = row.add("edittext", undefined, String(defaultVal));
                        editbox.preferredSize = [45, 20];

                        var resetBtn = row.add("button", undefined, "↺");
                        resetBtn.preferredSize = [20, 20];
                        resetBtn.helpTip = "Reset to default (" + defaultVal + ")";

                        // Sync slider -> editbox
                        slider.onChanging = function() {
                            editbox.text = (p.type === "slider" && p.unit === "fps") ? Math.round(slider.value) : (Math.round(slider.value * 10) / 10);
                        };

                        // Sync editbox -> slider
                        editbox.onChange = function() {
                            var val = parseFloat(editbox.text);
                            if (!isNaN(val)) {
                                slider.value = val;
                            }
                        };

                        resetBtn.onClick = function() {
                            slider.value = defaultVal;
                            editbox.text = String(defaultVal);
                        };

                        paramControlMap[p.id] = {
                            param: p,
                            slider: slider,
                            editbox: editbox,
                            defaultVal: defaultVal
                        };
                    })(recipe.parameters[i]);
                }

                paramPanel.layout.layout(true);
            }

            function collectCurrentParameterValues() {
                var values = {};
                for (var pId in paramControlMap) {
                    if (paramControlMap.hasOwnProperty(pId)) {
                        var ctrl = paramControlMap[pId];
                        var val = parseFloat(ctrl.editbox.text);
                        if (isNaN(val)) val = ctrl.slider.value;
                        values[pId] = val;
                    }
                }
                return values;
            }

            // --- EVENT WIRING ---
            btnRefresh.onClick = function() {
                refreshCompStatus();
            };

            catDropdown.onChange = function() {
                refreshRecipeList();
            };

            searchInput.onChanging = function() {
                refreshRecipeList();
            };

            recipeList.onChange = function() {
                if (recipeList.selection) {
                    var idx = recipeList.selection.index;
                    currentSelectedRecipe = currentRecipes[idx];
                    descLbl.text = currentSelectedRecipe.description || "";
                    audioGroup.enabled = !!currentSelectedRecipe.requiresAudio;
                    renderParameters(currentSelectedRecipe);
                } else {
                    currentSelectedRecipe = null;
                    descLbl.text = "";
                    clearParamPanel();
                }
            };

            btnApply.onClick = function() {
                refreshCompStatus();
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Please select a behavior first.";
                    return;
                }
                var comp = vac34_AEDom.getActiveComp();
                var layers = vac34_AEDom.getSelectedLayers(comp);
                var pVals = collectCurrentParameterValues();
                var isMaster = rbMaster.value;
                var audioLyr = (audioLayerDrop.selection) ? audioLayerDrop.selection.text : vac34_Config.AUDIO_LAYER_NAME;
                var audioChan = (audioChanDrop.selection) ? audioChanDrop.selection.text : "Both Channels";

                var res = vac34_Engine.applyRecipe(comp, layers, currentSelectedRecipe, pVals, isMaster, audioLyr, audioChan);
                var msg = res.message;
                if (res.warnings && res.warnings.length > 0) {
                    msg += "\n" + res.warnings.join("\n");
                }
                statusBox.text = msg;
            };

            btnUpdate.onClick = function() {
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Please select a behavior first.";
                    return;
                }
                var comp = vac34_AEDom.getActiveComp();
                var layers = vac34_AEDom.getSelectedLayers(comp);
                var pVals = collectCurrentParameterValues();
                var isMaster = rbMaster.value;

                var res = vac34_Engine.updateParameters(comp, layers, currentSelectedRecipe, pVals, isMaster);
                statusBox.text = res.message;
            };

            btnRemove.onClick = function() {
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Please select a behavior first.";
                    return;
                }
                var comp = vac34_AEDom.getActiveComp();
                var layers = vac34_AEDom.getSelectedLayers(comp);

                var res = vac34_Engine.removeRecipe(comp, layers, currentSelectedRecipe);
                statusBox.text = res.message;
            };

            btnSavePreset.onClick = function() {
                if (!currentSelectedRecipe) {
                    statusBox.text = "Error: Select a behavior before saving preset.";
                    return;
                }
                var name = prompt("Enter Preset Name:", currentSelectedRecipe.displayName + " Custom");
                if (name) {
                    var pVals = collectCurrentParameterValues();
                    var saved = vac34_PresetManager.savePreset(name, currentSelectedRecipe.id, pVals, rbMaster.value);
                    if (saved) {
                        statusBox.text = "Preset '" + name + "' saved successfully.";
                    } else {
                        statusBox.text = "Failed to save preset.";
                    }
                }
            };

            btnLoadPreset.onClick = function() {
                var presets = vac34_PresetManager.listPresets();
                if (presets.length === 0) {
                    statusBox.text = "No saved presets found in user folder.";
                    return;
                }
                var pWin = new Window("dialog", "Load Preset");
                pWin.orientation = "column";
                pWin.alignChildren = ["fill", "top"];
                var pList = pWin.add("listbox", undefined, presets);
                pList.selection = 0;
                pList.preferredSize = [200, 150];

                var pBtnRow = pWin.add("group");
                var btnOk = pBtnRow.add("button", undefined, "Load");
                var btnCancel = pBtnRow.add("button", undefined, "Cancel");

                btnOk.onClick = function() {
                    if (pList.selection) {
                        var pName = pList.selection.text;
                        var pData = vac34_PresetManager.loadPreset(pName);
                        if (pData) {
                            var rec = vac34_RecipeRegistry.getRecipeById(pData.recipeId);
                            if (rec) {
                                // Select recipe
                                for (var i = 0; i < currentRecipes.length; i++) {
                                    if (currentRecipes[i].id === rec.id) {
                                        recipeList.selection = i;
                                        break;
                                    }
                                }
                                // Fill params
                                if (pData.parameters) {
                                    for (var pKey in pData.parameters) {
                                        if (paramControlMap[pKey]) {
                                            paramControlMap[pKey].slider.value = pData.parameters[pKey];
                                            paramControlMap[pKey].editbox.text = String(pData.parameters[pKey]);
                                        }
                                    }
                                }
                                rbMaster.value = !!pData.masterMode;
                                rbPerLayer.value = !pData.masterMode;
                                statusBox.text = "Loaded preset '" + pName + "'.";
                            }
                        }
                    }
                    pWin.close();
                };
                btnCancel.onClick = function() { pWin.close(); };
                pWin.show();
            };

            // Window resize handler
            win.onResizing = win.onResize = function() {
                this.layout.resize();
            };

            // Initial population
            refreshCompStatus();
            refreshRecipeList();

            return win;
        }
    };
})();
