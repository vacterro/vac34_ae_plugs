/*
 * vac34_AE — Master Expressions Studio
 * AudioEngine: Audio source discovery, channel routing & temporal envelope generation
 */

var vac34_AudioEngine = (function() {
    return {
        findAudioLayers: function(comp) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!comp) return [];
            var found = [];
            for (var i = 1; i <= comp.numLayers; i++) {
                var l = comp.layer(i);
                // Check if name contains audio or if it has Audio Amplitude effects
                var effects = l.property("ADBE Effect Parade") || l.property("Effects");
                var hasAudioSliders = false;
                if (effects) {
                    if (effects.property("Both Channels") || effects.property("Left Channel") || effects.property("Right Channel")) {
                        hasAudioSliders = true;
                    }
                }
                if (l.name === vac34_Config.AUDIO_LAYER_NAME || hasAudioSliders) {
                    found.push({
                        index: i,
                        name: l.name,
                        layer: l,
                        hasBoth: !!(effects && effects.property("Both Channels")),
                        hasLeft: !!(effects && effects.property("Left Channel")),
                        hasRight: !!(effects && effects.property("Right Channel"))
                    });
                }
            }
            return found;
        },

        getPrimaryAudioLayerName: function(comp) {
            var layers = this.findAudioLayers(comp);
            if (layers.length > 0) {
                return layers[0].name;
            }
            return vac34_Config.AUDIO_LAYER_NAME;
        },

        generateAudioLinkCode: function(audioLayerName, channelName) {
            var safeName = audioLayerName || vac34_Config.AUDIO_LAYER_NAME;
            var safeChannel = channelName || "Both Channels";
            return [
                '// [vac34: Audio Link]',
                'var _audioLyr = null;',
                'try { _audioLyr = thisComp.layer("' + safeName + '"); } catch(e) {}',
                'var _rawAmp = 0;',
                'if (_audioLyr && _audioLyr.effect && _audioLyr.effect("' + safeChannel + '")) {',
                '    _rawAmp = _audioLyr.effect("' + safeChannel + '")(1);',
                '} else {',
                '    _rawAmp = 0; // Fallback: no audio layer',
                '}'
            ].join('\n');
        },

        generateTemporalEnvelopeCode: function(audioLayerName, channelName, attackFrames, releaseFrames, threshold) {
            var safeName = audioLayerName || vac34_Config.AUDIO_LAYER_NAME;
            var safeChannel = channelName || "Both Channels";
            var maxLookback = 30; // Bound sampling to 30 frames for guaranteed UI responsiveness

            return [
                '// [vac34: Temporal Attack/Release Envelope (Bounded Lookback)]',
                'var _audioLyr = null;',
                'try { _audioLyr = thisComp.layer("' + safeName + '"); } catch(e) {}',
                'var _env = 0;',
                'if (_audioLyr && _audioLyr.effect && _audioLyr.effect("' + safeChannel + '")) {',
                '    var _ampProp = _audioLyr.effect("' + safeChannel + '")(1);',
                '    var _curTime = time;',
                '    var _fps = 1.0 / thisComp.frameDuration;',
                '    var _lookback = Math.min(' + maxLookback + ', Math.floor(_curTime * _fps));',
                '    var _peak = 0;',
                '    var _th = ' + (threshold || 5) + ';',
                '    for (var _f = 0; _f <= _lookback; _f++) {',
                '        var _tSample = _curTime - (_f * thisComp.frameDuration);',
                '        var _v = _ampProp.valueAtTime(_tSample);',
                '        if (_v >= _th) {',
                '            var _decay = Math.max(0, 1.0 - (_f / ' + (releaseFrames || 12) + '));',
                '            if (_decay > _peak) _peak = _decay;',
                '        }',
                '    }',
                '    _env = _peak;',
                '} else { _env = 0; }'
            ].join('\n');
        }
    };
})();
