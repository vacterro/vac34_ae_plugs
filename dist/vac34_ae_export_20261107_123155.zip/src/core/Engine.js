/*
 * vac34_AE — Master Expressions Studio
 * Engine: Execution Orchestrator with Strict Overwrite Protection & Guaranteed Undo Closure
 */

var vac34_Engine = (function() {
    return {
        applyRecipe: function(comp, layers, recipe, paramValues, isMasterMode, audioName, audioChan) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);

            var diag = vac34_Diagnostics.checkApplication(comp, layers, recipe);
            if (!diag.canApply) {
                return {
                    ok: false,
                    appliedCount: 0,
                    conflictCount: diag.conflictedLayers.length,
                    skipCount: diag.incompatibleLayers.length,
                    message: diag.errors.join("\n"),
                    warnings: diag.warnings
                };
            }

            vac34_AEDom.beginUndo("vac34_AE: Apply " + recipe.displayName);
            var successCount = 0;

            try {
                var masterLayer = null;
                if (isMasterMode) {
                    masterLayer = vac34_ControllerManager.getOrCreateMasterLayer(comp);
                    vac34_ControllerManager.setupRecipeControls(masterLayer, recipe, paramValues);
                }

                var targetPropPath = recipe.targetProperties ? recipe.targetProperties[0] : "Transform.Position";

                // Iterate ONLY through compatibleLayers (conflicted layers are untouched)
                for (var i = 0; i < diag.compatibleLayers.length; i++) {
                    var lyr = diag.compatibleLayers[i];

                    if (!isMasterMode) {
                        vac34_ControllerManager.setupRecipeControls(lyr, recipe, paramValues);
                    }

                    // Resolve property
                    var prop = null;
                    if (targetPropPath === "Any.Property") {
                        if (lyr.selectedProperties && lyr.selectedProperties.length > 0) {
                            for (var sp = 0; sp < lyr.selectedProperties.length; sp++) {
                                if (vac34_AEDom.canSetExpression(lyr.selectedProperties[sp])) {
                                    prop = lyr.selectedProperties[sp];
                                    break;
                                }
                            }
                        }
                        if (!prop && lyr.property("Transform")) {
                            prop = lyr.property("Transform").property("Position");
                        }
                    } else {
                        prop = vac34_AEDom.resolveProperty(lyr, targetPropPath);
                    }

                    // Re-verify that property is not foreign (double guard)
                    if (prop && vac34_AEDom.canSetExpression(prop) && !vac34_AEDom.hasForeignExpression(prop)) {
                        var masterName = masterLayer ? masterLayer.name : vac34_Config.MASTER_LAYER_NAME;
                        var expr = recipe.generateExpression(lyr, isMasterMode, masterName, paramValues, audioName, audioChan);
                        prop.expression = expr;
                        successCount++;
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            var conflictCount = diag.conflictedLayers.length;
            var skipCount = diag.incompatibleLayers.length;
            var summaryMsg = "Applied to " + successCount + " layer(s).";
            if (conflictCount > 0) {
                summaryMsg += " (" + conflictCount + " conflicted layer(s) preserved).";
            }
            if (skipCount > 0) {
                summaryMsg += " (" + skipCount + " incompatible layer(s) skipped).";
            }

            return {
                ok: (successCount > 0),
                appliedCount: successCount,
                conflictCount: conflictCount,
                skipCount: skipCount,
                message: summaryMsg,
                warnings: diag.warnings
            };
        },

        updateParameters: function(comp, layers, recipe, paramValues, isMasterMode) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);
            if (!recipe || !paramValues) return { ok: false, message: "Missing recipe or parameters." };

            vac34_AEDom.beginUndo("vac34_AE: Update " + recipe.displayName);
            var count = 0;

            try {
                if (isMasterMode) {
                    var master = vac34_ControllerManager.getOrCreateMasterLayer(comp);
                    if (master) {
                        for (var pId in paramValues) {
                            if (paramValues.hasOwnProperty(pId)) {
                                vac34_ControllerManager.updateParameterValue(master, recipe, pId, paramValues[pId]);
                            }
                        }
                        count = 1;
                    }
                } else {
                    for (var i = 0; i < layers.length; i++) {
                        var lyr = layers[i];
                        for (var pId in paramValues) {
                            if (paramValues.hasOwnProperty(pId)) {
                                vac34_ControllerManager.updateParameterValue(lyr, recipe, pId, paramValues[pId]);
                            }
                        }
                        count++;
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            return { ok: true, message: "Updated parameters for " + count + " target(s)." };
        },

        removeRecipe: function(comp, layers, recipe) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);
            if (!recipe) return { ok: false, message: "No recipe selected." };

            vac34_AEDom.beginUndo("vac34_AE: Remove " + recipe.displayName);
            var removedCount = 0;
            var targetPropPath = recipe.targetProperties ? recipe.targetProperties[0] : "Transform.Position";

            try {
                for (var i = 0; i < layers.length; i++) {
                    var lyr = layers[i];
                    var prop = vac34_AEDom.resolveProperty(lyr, targetPropPath);

                    // Check ownership before removing
                    var isOwned = false;
                    if (prop && vac34_AEDom.isVac34Expression(prop)) {
                        var recId = vac34_AEDom.extractVac34RecipeId(prop);
                        if (recId === recipe.id) {
                            isOwned = true;
                            prop.expression = "";
                            removedCount++;
                        }
                    }

                    // Only remove controllers if this recipe actually owned the property or controllers
                    if (isOwned) {
                        vac34_ControllerManager.removeRecipeControls(lyr, recipe);
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            return { ok: true, message: "Removed '" + recipe.displayName + "' from " + removedCount + " layer(s)." };
        }
    };
})();
