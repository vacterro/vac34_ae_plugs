/*
 * vac34_AE — Master Expressions Studio
 * ControllerManager: Manages native AE Expression Controls (Sliders, Angles, Checkboxes, Colors)
 */

var vac34_ControllerManager = (function() {
    var MATCH_NAMES = {
        "slider": "ADBE Slider Control",
        "checkbox": "ADBE Checkbox Control",
        "angle": "ADBE Angle Control",
        "color": "ADBE Color Control",
        "point": "ADBE Point Control",
        "layer": "ADBE Layer Control"
    };

    return {
        getOrCreateMasterLayer: function(comp) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!comp) return null;

            for (var i = 1; i <= comp.numLayers; i++) {
                if (comp.layer(i).name === vac34_Config.MASTER_LAYER_NAME) {
                    return comp.layer(i);
                }
            }

            // Create Master Null
            var master = comp.layers.addNull();
            master.name = vac34_Config.MASTER_LAYER_NAME;
            master.label = 13; // Distinct color label
            master.guideLayer = true;
            master.moveToBeginning();
            return master;
        },

        getEffectPrefixForRecipe: function(recipe) {
            return vac34_Config.EFFECT_PREFIX + recipe.displayName;
        },

        ensureParameterControl: function(targetLayer, recipe, param) {
            if (!targetLayer) return null;
            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return null;

            var effectName = this.getEffectPrefixForRecipe(recipe) + " — " + param.name;
            var matchName = MATCH_NAMES[param.type.toLowerCase()] || "ADBE Slider Control";

            // Check if already exists
            var existing = effectsGroup.property(effectName);
            if (existing) {
                return existing;
            }

            try {
                var newEffect = effectsGroup.addProperty(matchName);
                if (newEffect) {
                    newEffect.name = effectName;
                    var valProp = newEffect.property(1); // Primary value property
                    if (valProp && param["default"] !== undefined) {
                        valProp.setValue(param["default"]);
                    }
                    return newEffect;
                }
            } catch (e) {
                return null;
            }
            return null;
        },

        setupRecipeControls: function(targetLayer, recipe, values) {
            if (!targetLayer || !recipe || !recipe.parameters) return {};
            var controls = {};
            for (var i = 0; i < recipe.parameters.length; i++) {
                var p = recipe.parameters[i];
                var effect = this.ensureParameterControl(targetLayer, recipe, p);
                if (effect) {
                    var valProp = effect.property(1);
                    if (valProp && values && values[p.id] !== undefined) {
                        try {
                            valProp.setValue(values[p.id]);
                        } catch (e) {}
                    }
                    controls[p.id] = effect;
                }
            }
            return controls;
        },

        updateParameterValue: function(targetLayer, recipe, paramId, value) {
            if (!targetLayer || !recipe) return false;
            var param = null;
            for (var i = 0; i < recipe.parameters.length; i++) {
                if (recipe.parameters[i].id === paramId) {
                    param = recipe.parameters[i];
                    break;
                }
            }
            if (!param) return false;

            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return false;

            var effectName = this.getEffectPrefixForRecipe(recipe) + " — " + param.name;
            var effect = effectsGroup.property(effectName);
            if (effect) {
                var valProp = effect.property(1);
                if (valProp) {
                    try {
                        valProp.setValue(value);
                        return true;
                    } catch (e) {
                        return false;
                    }
                }
            }
            return false;
        },

        removeRecipeControls: function(targetLayer, recipe) {
            if (!targetLayer || !recipe) return 0;
            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return 0;

            var removed = 0;
            var prefix = this.getEffectPrefixForRecipe(recipe);
            // Iterate backwards to avoid index invalidation
            for (var i = effectsGroup.numProperties; i >= 1; i--) {
                var eff = effectsGroup.property(i);
                if (eff && eff.name.indexOf(prefix) === 0) {
                    eff.remove();
                    removed++;
                }
            }
            return removed;
        }
    };
})();
