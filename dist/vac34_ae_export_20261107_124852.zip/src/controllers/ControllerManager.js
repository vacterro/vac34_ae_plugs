/*
 * vac34_AE — Master Expressions Studio
 * ControllerManager: Strict Native AE Expression Controls Orchestration
 */

var vac34_ControllerManager = (function() {
    var MATCH_NAMES = {
        "slider": "ADBE Slider Control",
        "checkbox": "ADBE Checkbox Control",
        "angle": "ADBE Angle Control",
        "color": "ADBE Color Control",
        "point": "ADBE Point Control",
        "layer": "ADBE Layer Control"
    };

    return {
        getOrCreateMasterLayer: function(comp) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!comp) return null;

            for (var i = 1; i <= comp.numLayers; i++) {
                if (comp.layer(i).name === vac34_Config.MASTER_LAYER_NAME) {
                    return comp.layer(i);
                }
            }

            // Create Master Null
            try {
                var master = comp.layers.addNull();
                master.name = vac34_Config.MASTER_LAYER_NAME;
                master.label = 13;
                master.guideLayer = true;
                master.moveToBeginning();
                return master;
            } catch (e) {
                return null;
            }
        },

        getEffectPrefixForRecipe: function(recipe) {
            return vac34_Config.EFFECT_PREFIX + recipe.displayName;
        },

        ensureParameterControl: function(targetLayer, recipe, param) {
            if (!targetLayer) return null;
            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return null;

            var effectName = this.getEffectPrefixForRecipe(recipe) + " — " + param.name;
            var expectedMatch = MATCH_NAMES[param.type.toLowerCase()] || "ADBE Slider Control";

            // Check if already exists and verify matchName
            var existing = effectsGroup.property(effectName);
            if (existing) {
                if (existing.matchName === expectedMatch) {
                    return existing;
                }
                // Name collision with different matchName - cannot safely reuse
                return null;
            }

            try {
                if (effectsGroup.canAddProperty && !effectsGroup.canAddProperty(expectedMatch)) {
                    return null;
                }
                var newEffect = effectsGroup.addProperty(expectedMatch);
                if (newEffect) {
                    newEffect.name = effectName;
                    var valProp = newEffect.property(1);
                    if (valProp && param["default"] !== undefined) {
                        try {
                            valProp.setValue(param["default"]);
                        } catch (e) {}
                    }
                    return newEffect;
                }
            } catch (e) {
                return null;
            }
            return null;
        },

        setupRecipeControls: function(targetLayer, recipe, values) {
            if (!targetLayer || !recipe || !recipe.parameters) return null;
            var controls = {};
            var createdEffects = [];

            for (var i = 0; i < recipe.parameters.length; i++) {
                var p = recipe.parameters[i];
                var effect = this.ensureParameterControl(targetLayer, recipe, p);
                if (!effect) {
                    // P0: Transaction failure rollback! Remove any partially created effects
                    for (var c = 0; c < createdEffects.length; c++) {
                        try { createdEffects[c].remove(); } catch (e) {}
                    }
                    return null;
                }
                createdEffects.push(effect);

                var valProp = effect.property(1);
                if (valProp && values && values[p.id] !== undefined) {
                    try {
                        valProp.setValue(values[p.id]);
                    } catch (e) {}
                }
                controls[p.id] = effect;
            }
            return controls;
        },

        updateParameterValue: function(targetLayer, recipe, paramId, value) {
            if (!targetLayer || !recipe) return false;
            var param = null;
            for (var i = 0; i < recipe.parameters.length; i++) {
                if (recipe.parameters[i].id === paramId) {
                    param = recipe.parameters[i];
                    break;
                }
            }
            if (!param) return false;

            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return false;

            var effectName = this.getEffectPrefixForRecipe(recipe) + " — " + param.name;
            var effect = effectsGroup.property(effectName);
            if (effect) {
                var valProp = effect.property(1);
                if (valProp) {
                    try {
                        valProp.setValue(value);
                        return true;
                    } catch (e) {
                        return false;
                    }
                }
            }
            return false;
        },

        removeRecipeControls: function(targetLayer, recipe) {
            if (!targetLayer || !recipe) return 0;
            var effectsGroup = targetLayer.property("ADBE Effect Parade") || targetLayer.property("Effects");
            if (!effectsGroup) return 0;

            var removed = 0;
            var prefix = this.getEffectPrefixForRecipe(recipe);
            for (var i = effectsGroup.numProperties; i >= 1; i--) {
                var eff = effectsGroup.property(i);
                if (eff && eff.name && eff.name.indexOf(prefix) === 0) {
                    eff.remove();
                    removed++;
                }
            }
            return removed;
        }
    };
})();
