/*
 * vac34_AE — Master Expressions Studio
 * PresetManager: Pure-JS Recursive Descent JSON Parser & Strict Schema Validator
 * ZERO eval / ZERO Function execution.
 */

var vac34_PresetManager = (function() {
    function getPresetFolder() {
        var userDataPath = (typeof Folder !== "undefined" && Folder.userData) ? Folder.userData.fsName : ".";
        var folder = new Folder(userDataPath + "/" + vac34_Config.PRESET_DIR_NAME);
        if (!folder.exists) {
            folder.create();
        }
        return folder;
    }

    // Pure JavaScript Recursive Descent JSON Parser (Zero eval, Zero Function)
    function parseJSONStrict(source) {
        var at = 0;
        var ch = ' ';

        function error(m) {
            throw new Error("JSON Parse Error: " + m + " at position " + at);
        }

        function next(c) {
            if (c && c !== ch) {
                error("Expected '" + c + "' instead of '" + ch + "'");
            }
            ch = source.charAt(at);
            at += 1;
            return ch;
        }

        function white() {
            while (ch && ch <= ' ') {
                next();
            }
        }

        function parseString() {
            var s = '';
            if (ch === '"') {
                while (next()) {
                    if (ch === '"') {
                        next();
                        return s;
                    }
                    if (ch === '\\') {
                        next();
                        if (ch === 'u') {
                            var uffff = 0;
                            for (var i = 0; i < 4; i += 1) {
                                var hex = parseInt(next(), 16);
                                if (!isFinite(hex)) {
                                    error("Bad unicode escape");
                                }
                                uffff = uffff * 16 + hex;
                            }
                            s += String.fromCharCode(uffff);
                        } else if (ch === '"' || ch === '\\' || ch === '/') {
                            s += ch;
                        } else if (ch === 'b') {
                            s += '\b';
                        } else if (ch === 'f') {
                            s += '\f';
                        } else if (ch === 'n') {
                            s += '\n';
                        } else if (ch === 'r') {
                            s += '\r';
                        } else if (ch === 't') {
                            s += '\t';
                        } else {
                            error("Bad escape character");
                        }
                    } else {
                        s += ch;
                    }
                }
            }
            error("Bad string");
        }

        function parseNumber() {
            var n = '';
            if (ch === '-') {
                n = '-';
                next('-');
            }
            while (ch >= '0' && ch <= '9') {
                n += ch;
                next();
            }
            if (ch === '.') {
                n += '.';
                while (next() && ch >= '0' && ch <= '9') {
                    n += ch;
                }
            }
            if (ch === 'e' || ch === 'E') {
                n += ch;
                next();
                if (ch === '-' || ch === '+') {
                    n += ch;
                    next();
                }
                while (ch >= '0' && ch <= '9') {
                    n += ch;
                    next();
                }
            }
            var num = Number(n);
            if (!isFinite(num)) {
                error("Bad number");
            }
            return num;
        }

        function parseWord() {
            switch (ch) {
                case 't':
                    next('t'); next('r'); next('u'); next('e');
                    return true;
                case 'f':
                    next('f'); next('a'); next('l'); next('s'); next('e');
                    return false;
                case 'n':
                    next('n'); next('u'); next('l'); next('l');
                    return null;
            }
            error("Unexpected word token '" + ch + "'");
        }

        function parseArray() {
            var arr = [];
            if (ch === '[') {
                next('[');
                white();
                if (ch === ']') {
                    next(']');
                    return arr;
                }
                while (ch) {
                    arr.push(parseValue());
                    white();
                    if (ch === ']') {
                        next(']');
                        return arr;
                    }
                    next(',');
                    white();
                }
            }
            error("Bad array");
        }

        function parseObject() {
            var obj = {};
            if (ch === '{') {
                next('{');
                white();
                if (ch === '}') {
                    next('}');
                    return obj;
                }
                while (ch) {
                    var k = parseString();
                    white();
                    next(':');
                    obj[k] = parseValue();
                    white();
                    if (ch === '}') {
                        next('}');
                        return obj;
                    }
                    next(',');
                    white();
                }
            }
            error("Bad object");
        }

        function parseValue() {
            white();
            switch (ch) {
                case '{': return parseObject();
                case '[': return parseArray();
                case '"': return parseString();
                case '-': return parseNumber();
                default:
                    return (ch >= '0' && ch <= '9') ? parseNumber() : parseWord();
            }
        }

        next();
        var result = parseValue();
        white();
        if (ch) {
            error("Syntax error, trailing characters after JSON");
        }
        return result;
    }

    return {
        getPresetFolder: getPresetFolder,
        parseJSONStrict: parseJSONStrict,

        listPresets: function() {
            var folder = getPresetFolder();
            if (!folder.exists) return [];
            var files = folder.getFiles("*.json");
            var names = [];
            for (var i = 0; i < files.length; i++) {
                var f = files[i];
                var name = decodeURI(f.name).replace(/\.json$/i, "");
                names.push(name);
            }
            return names;
        },

        savePreset: function(presetName, recipeId, paramValues, masterMode) {
            if (!presetName || !recipeId) return false;
            var cleanName = presetName.replace(/[^a-zA-Z0-9_\-\s]/g, "");
            if (cleanName === "") cleanName = "Preset";

            var folder = getPresetFolder();
            var file = new File(folder.fsName + "/" + cleanName + ".json");
            var data = {
                product: vac34_Config.PRODUCT_NAME,
                version: vac34_Config.VERSION,
                recipeId: recipeId,
                masterMode: !!masterMode,
                parameters: paramValues || {},
                createdAt: (new Date()).toUTCString()
            };

            try {
                file.encoding = "UTF-8";
                file.open("w");
                file.write(JSON.stringify(data));
                return true;
            } catch (e) {
                return false;
            } finally {
                try { file.close(); } catch (e) {}
            }
        },

        loadPreset: function(presetName) {
            var cleanName = presetName.replace(/[^a-zA-Z0-9_\-\s]/g, "");
            var folder = getPresetFolder();
            var file = new File(folder.fsName + "/" + cleanName + ".json");
            if (!file.exists) return null;

            var content = "";
            try {
                file.encoding = "UTF-8";
                file.open("r");
                content = file.read();
            } catch (e) {
                return null;
            } finally {
                try { file.close(); } catch (e) {}
            }

            try {
                // Strictly parse without eval
                var data = parseJSONStrict(content);

                // Strict Schema Validation
                if (!data || typeof data !== "object") return null;
                if (!data.recipeId || typeof data.recipeId !== "string") return null;
                if (!data.parameters || typeof data.parameters !== "object" || (data.parameters instanceof Array)) return null;

                // Validate parameters dictionary values (only numbers, booleans, strings allowed)
                for (var key in data.parameters) {
                    if (data.parameters.hasOwnProperty(key)) {
                        var val = data.parameters[key];
                        var t = typeof val;
                        if (t !== "number" && t !== "boolean" && t !== "string") {
                            return null;
                        }
                        if (t === "number" && !isFinite(val)) {
                            return null;
                        }
                    }
                }

                return data;
            } catch (e) {
                return null;
            }
        }
    };
})();
