@echo off
setlocal enabledelayedexpansion
title vac34_AE Live Panel Elevated Installer

:: Check for Administrator elevation
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [REQUESTING ELEVATION] Restarting with Administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ========================================================
echo  vac34_AE — Master Expressions Studio Live Installer
echo ========================================================
echo.

set "SCRIPT_DIR=%~dp0"
set "WORKSPACE_ROOT=%SCRIPT_DIR%.."
set "DIST_FILE=%WORKSPACE_ROOT%\dist\vac34_AE.jsx"
set "LIVE_DIR=C:\Program Files\Adobe\Adobe After Effects 2024\Support Files\Scripts\ScriptUI Panels"
set "LIVE_TARGET=%LIVE_DIR%\vac34_AE.jsx"

if not exist "%DIST_FILE%" (
    echo [ERROR] Distribution file not found at: "%DIST_FILE%"
    echo Run python build/builder.py first.
    pause
    exit /b 1
)

if not exist "%LIVE_DIR%" (
    echo [WARNING] Live AE ScriptUI Panels directory not found at: "%LIVE_DIR%"
    echo Creating target directory...
    mkdir "%LIVE_DIR%" 2>nul
)

if exist "%LIVE_TARGET%" (
    echo Backing up existing Live JSX to vac34_AE.jsx.bak...
    copy /y "%LIVE_TARGET%" "%LIVE_TARGET%.bak" >nul
)

echo Deploying %DIST_FILE% to %LIVE_TARGET%...
copy /y "%DIST_FILE%" "%LIVE_TARGET%" >nul

if %errorLevel% equ 0 (
    echo.
    echo [SUCCESS] Live installation completed successfully!
    echo Target: %LIVE_TARGET%
    echo.
    echo Verifying installation hashes...
    powershell -Command "$d = (Get-FileHash -Algorithm SHA256 '%DIST_FILE%').Hash; $l = (Get-FileHash -Algorithm SHA256 '%LIVE_TARGET%').Hash; Write-Host ('Dist SHA: ' + $d); Write-Host ('Live SHA: ' + $l); if ($d -eq $l) { Write-Host '[VERIFIED] Dist and Live SHA-256 match 100%!' -ForegroundColor Green } else { Write-Host '[MISMATCH] Hashes do not match!' -ForegroundColor Red }"
) else (
    echo.
    echo [ERROR] Failed to copy file to %LIVE_TARGET%.
)

echo.
echo Press any key to close this window.
pause >nul
