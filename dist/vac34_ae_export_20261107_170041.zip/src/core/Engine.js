/*
 * vac34_AE — Master Expressions Studio
 * Engine: Execution Orchestrator with Rigorous Dependency Validation & Reversible Transactions
 */

var vac34_Engine = (function() {
    function findVac34PropertyOnLayer(layer, recipeId) {
        if (!layer) return null;
        // Check transform properties
        var xform = layer.property("Transform");
        if (xform) {
            for (var p = 1; p <= xform.numProperties; p++) {
                var prop = xform.property(p);
                if (prop && vac34_AEDom.isVac34Expression(prop)) {
                    if (!recipeId || vac34_AEDom.extractVac34RecipeId(prop) === recipeId) {
                        return prop;
                    }
                }
            }
        }
        return null;
    }

    return {
        applyRecipe: function(comp, layers, recipe, paramValues, isMasterMode, audioName, audioChan) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);

            var diag = vac34_Diagnostics.checkApplication(comp, layers, recipe);
            if (!diag.canApply) {
                return {
                    ok: false,
                    appliedCount: 0,
                    failedCount: 0,
                    conflictCount: diag.conflictedLayers.length,
                    skipCount: diag.incompatibleLayers.length,
                    message: diag.errors.join("\n"),
                    warnings: diag.warnings
                };
            }

            vac34_AEDom.beginUndo("vac34_AE: Apply " + recipe.displayName);
            var successCount = 0;
            var failureCount = 0;

            try {
                var masterLayer = null;
                var masterControls = null;
                var masterIsNew = false;
                if (isMasterMode) {
                    masterLayer = vac34_ControllerManager.getOrCreateMasterLayer(comp);
                    if (!masterLayer) {
                        diag.errors.push("Failed to create or access Shared Master Null layer.");
                        return { ok: false, appliedCount: 0, failedCount: diag.compatibleLayers.length, message: diag.errors.join("\n") };
                    }
                    masterIsNew = !!masterLayer._vac34IsNew;
                    masterControls = vac34_ControllerManager.setupRecipeControls(masterLayer, recipe, paramValues);
                    if (!masterControls) {
                        diag.errors.push("Failed to initialize required Expression Controls on Shared Master Null.");
                        if (masterIsNew) {
                            try { masterLayer.remove(); } catch (e) {}
                        }
                        return { ok: false, appliedCount: 0, failedCount: diag.compatibleLayers.length, message: diag.errors.join("\n") };
                    }
                }

                var targetPropPath = recipe.targetProperties ? recipe.targetProperties[0] : "Transform.Position";

                for (var i = 0; i < diag.compatibleLayers.length; i++) {
                    var lyr = diag.compatibleLayers[i];
                    var ctrlMap = null;

                    // Per-layer parameter controls creation
                    if (!isMasterMode) {
                        ctrlMap = vac34_ControllerManager.setupRecipeControls(lyr, recipe, paramValues);
                        if (!ctrlMap) {
                            // P0: Controller creation failure -> refuse to set expression!
                            failureCount++;
                            diag.warnings.push("Failed to create required Expression Controls on layer '" + lyr.name + "'. Skipped.");
                            continue;
                        }
                    }

                    // Resolve target property
                    var prop = null;
                    if (targetPropPath === "Any.Property") {
                        if (lyr.selectedProperties && lyr.selectedProperties.length > 0) {
                            for (var sp = 0; sp < lyr.selectedProperties.length; sp++) {
                                if (vac34_AEDom.canSetExpression(lyr.selectedProperties[sp])) {
                                    prop = lyr.selectedProperties[sp];
                                    break;
                                }
                            }
                        }
                        if (!prop && lyr.property("Transform")) {
                            prop = lyr.property("Transform").property("Position");
                        }
                    } else {
                        prop = vac34_AEDom.resolveProperty(lyr, targetPropPath);
                    }

                    // Final pre-check: ensure property exists and has no foreign expression
                    if (prop && vac34_AEDom.canSetExpression(prop) && !vac34_AEDom.hasForeignExpression(prop)) {
                        var masterName = masterLayer ? masterLayer.name : vac34_Config.MASTER_LAYER_NAME;
                        var expr = recipe.generateExpression(lyr, isMasterMode, masterName, paramValues, audioName, audioChan);

                        try {
                            prop.expression = expr;
                            if (ctrlMap && ctrlMap._tx) {
                                ctrlMap._tx.commit();
                            }
                            successCount++;
                        } catch (exprErr) {
                            // P0: Rollback newly created controls only, restore modified values on reused controls
                            if (ctrlMap && ctrlMap._tx) {
                                ctrlMap._tx.rollback();
                            }
                            failureCount++;
                            diag.warnings.push("Expression assignment failed on layer '" + lyr.name + "': " + exprErr.message);
                        }
                    } else {
                        failureCount++;
                        if (ctrlMap && ctrlMap._tx) {
                            ctrlMap._tx.rollback();
                        }
                    }
                }

                // P0 Shared Master Transaction: rollback if all applications failed, commit if any succeeded
                if (isMasterMode && masterControls && masterControls._tx) {
                    if (successCount === 0) {
                        masterControls._tx.rollback();
                        if (masterIsNew && masterLayer) {
                            var mEffects = masterLayer.property("ADBE Effect Parade") || masterLayer.property("Effects");
                            if (!mEffects || mEffects.numProperties === 0) {
                                try { masterLayer.remove(); } catch (e) {}
                            }
                        }
                    } else {
                        masterControls._tx.commit();
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            var conflictCount = diag.conflictedLayers.length;
            var skipCount = diag.incompatibleLayers.length;
            var isOk = (successCount > 0 && failureCount === 0);

            var summaryMsg = "Applied '" + recipe.displayName + "' to " + successCount + " layer(s).";
            if (failureCount > 0) {
                summaryMsg += " (" + failureCount + " layer(s) failed dependency creation).";
            }
            if (conflictCount > 0) {
                summaryMsg += " (" + conflictCount + " conflicted layer(s) preserved).";
            }
            if (skipCount > 0) {
                summaryMsg += " (" + skipCount + " incompatible layer(s) skipped).";
            }

            return {
                ok: isOk,
                appliedCount: successCount,
                failedCount: failureCount,
                conflictCount: conflictCount,
                skipCount: skipCount,
                message: summaryMsg,
                warnings: diag.warnings
            };
        },

        updateParameters: function(comp, layers, recipe, paramValues, isMasterMode) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);
            if (!recipe || !paramValues) return { ok: false, updatedCount: 0, message: "Missing recipe or parameters." };

            vac34_AEDom.beginUndo("vac34_AE: Update " + recipe.displayName);
            var updatedCount = 0;

            try {
                if (isMasterMode) {
                    var master = vac34_ControllerManager.getOrCreateMasterLayer(comp);
                    if (master) {
                        for (var pId in paramValues) {
                            if (paramValues.hasOwnProperty(pId)) {
                                if (vac34_ControllerManager.updateParameterValue(master, recipe, pId, paramValues[pId])) {
                                    updatedCount++;
                                }
                            }
                        }
                    }
                } else {
                    for (var i = 0; i < layers.length; i++) {
                        var lyr = layers[i];
                        for (var pId in paramValues) {
                            if (paramValues.hasOwnProperty(pId)) {
                                if (vac34_ControllerManager.updateParameterValue(lyr, recipe, pId, paramValues[pId])) {
                                    updatedCount++;
                                }
                            }
                        }
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            var ok = (updatedCount > 0);
            return {
                ok: ok,
                updatedCount: updatedCount,
                message: ok ? "Successfully updated " + updatedCount + " parameter value(s)." : "No matching active controls found to update."
            };
        },

        removeRecipe: function(comp, layers, recipe) {
            if (!comp) comp = vac34_AEDom.getActiveComp();
            if (!layers) layers = vac34_AEDom.getSelectedLayers(comp);
            if (!recipe) return { ok: false, removedCount: 0, message: "No recipe selected." };

            vac34_AEDom.beginUndo("vac34_AE: Remove " + recipe.displayName);
            var removedCount = 0;
            var targetPropPath = recipe.targetProperties ? recipe.targetProperties[0] : "Transform.Position";

            try {
                for (var i = 0; i < layers.length; i++) {
                    var lyr = layers[i];
                    var prop = null;

                    if (targetPropPath === "Any.Property") {
                        prop = findVac34PropertyOnLayer(lyr, recipe.id);
                    } else {
                        prop = vac34_AEDom.resolveProperty(lyr, targetPropPath);
                    }

                    var isOwned = false;
                    if (prop && vac34_AEDom.isVac34Expression(prop)) {
                        var recId = vac34_AEDom.extractVac34RecipeId(prop);
                        if (recId === recipe.id) {
                            isOwned = true;
                            prop.expression = "";
                            removedCount++;
                        }
                    }

                    // Only remove controls if this recipe actually owned the expression
                    if (isOwned) {
                        vac34_ControllerManager.removeRecipeControls(lyr, recipe);
                    }
                }
            } finally {
                vac34_AEDom.endUndo();
            }

            return {
                ok: (removedCount > 0),
                removedCount: removedCount,
                message: "Removed '" + recipe.displayName + "' from " + removedCount + " layer(s)."
            };
        }
    };
})();
