/**
 * vac34_AE — Master Expressions Studio
 * Version 0.0.1
 * Entry Point
 */

try {
    if (typeof vac34_UIBuilder !== "undefined") {
        var ui = vac34_UIBuilder.build(thisObj);
        if (ui) {
            if (typeof Window !== "undefined" && (ui instanceof Window)) {
                if (ui.layout) {
                    ui.layout.layout(true);
                }
                ui.center();
                ui.show();
            } else if (ui.layout) {
                ui.layout.layout(true);
                ui.layout.resize();
            }
        }
    }
} catch (e) {
    var stage = (typeof vac34_Diagnostics !== "undefined") ? vac34_Diagnostics.getCurrentStartupStage() : "Startup";
    if (typeof alert !== "undefined") {
        alert("vac34_AE Initialization Error [" + stage + "]: " + (e.message || e) + (e.line ? ("\nLine: " + e.line) : ""));
    }
}
