/*
 * vac34_AE — Master Expressions Studio
 * AE DOM Adapter: Safe interaction with After Effects Object Model
 */

var vac34_AEDom = (function() {
    var _undoDepth = 0;

    return {
        getActiveComp: function() {
            if (typeof app !== "undefined" && app.project && app.project.activeItem && (app.project.activeItem instanceof CompItem)) {
                return app.project.activeItem;
            }
            return null;
        },

        getSelectedLayers: function(comp) {
            if (!comp) comp = this.getActiveComp();
            if (!comp) return [];
            var layers = [];
            for (var i = 0; i < comp.selectedLayers.length; i++) {
                layers.push(comp.selectedLayers[i]);
            }
            return layers;
        },

        beginUndo: function(name) {
            try {
                if (_undoDepth === 0 && typeof app !== "undefined" && app.beginUndoGroup) {
                    app.beginUndoGroup(name || "vac34_AE Action");
                }
                _undoDepth++;
            } catch (e) {
                _undoDepth = 0;
            }
        },

        endUndo: function() {
            try {
                if (_undoDepth > 0) {
                    _undoDepth--;
                    if (_undoDepth === 0 && typeof app !== "undefined" && app.endUndoGroup) {
                        app.endUndoGroup();
                    }
                }
            } catch (e) {
                _undoDepth = 0;
            }
        },

        getUndoDepth: function() {
            return _undoDepth;
        },

        resolveProperty: function(layer, propPath) {
            if (!layer) return null;
            var parts = propPath.split(".");
            var current = layer;
            for (var i = 0; i < parts.length; i++) {
                var p = parts[i];
                try {
                    if (current.property) {
                        current = current.property(p);
                    } else {
                        return null;
                    }
                } catch (e) {
                    return null;
                }
                if (!current) return null;
            }
            return current;
        },

        canSetExpression: function(prop) {
            if (!prop) return false;
            try {
                if (prop.dimensionsSeparated === true) {
                    return false;
                }
                return (prop.canSetExpression === true);
            } catch (e) {
                return false;
            }
        },

        isVac34Expression: function(prop) {
            if (!prop || !prop.expression) return false;
            var expr = prop.expression.replace(/^\s+/, "");
            return (expr.indexOf(vac34_Config.TAG_PREFIX) === 0);
        },

        extractVac34RecipeId: function(prop) {
            if (!prop || !prop.expression) return null;
            var expr = prop.expression.replace(/^\s+/, "");
            if (expr.indexOf(vac34_Config.TAG_PREFIX) !== 0) return null;
            var start = vac34_Config.TAG_PREFIX.length;
            var end = expr.indexOf(vac34_Config.TAG_SUFFIX, start);
            if (end !== -1) {
                return expr.substring(start, end).replace(/^\s+|\s+$/g, "");
            }
            return null;
        },

        findRecipeProperty: function(layer, recipeId) {
            if (!layer) return null;
            var xform = layer.property("Transform");
            if (xform) {
                for (var p = 1; p <= xform.numProperties; p++) {
                    var prop = xform.property(p);
                    if (prop && this.isVac34Expression(prop)) {
                        if (!recipeId || this.extractVac34RecipeId(prop) === recipeId) {
                            return prop;
                        }
                    }
                }
            }
            return null;
        },

        hasForeignExpression: function(prop) {
            if (!prop || !prop.expression) return false;
            var trimmed = prop.expression.replace(/^\s+|\s+$/g, "");
            if (trimmed === "") return false;
            return !this.isVac34Expression(prop);
        },

        isLayer3D: function(layer) {
            if (!layer) return false;
            try {
                return (layer.threeDLayer === true);
            } catch (e) {
                return false;
            }
        },

        getPropertyDimension: function(layer, prop) {
            if (!prop) return 0;
            try {
                if (typeof PropertyValueType !== "undefined") {
                    if (prop.propertyValueType === PropertyValueType.OneD) return 1;
                    if (prop.propertyValueType === PropertyValueType.TwoD || prop.propertyValueType === PropertyValueType.TwoD_SPATIAL) {
                        if (this.isLayer3D(layer)) {
                            var mName = prop.matchName || "";
                            if (mName === "ADBE Position" || mName === "ADBE Scale" || mName === "ADBE Anchor Point") {
                                return 3;
                            }
                        }
                        return 2;
                    }
                    if (prop.propertyValueType === PropertyValueType.ThreeD || prop.propertyValueType === PropertyValueType.ThreeD_SPATIAL) return 3;
                    if (prop.propertyValueType === PropertyValueType.COLOR) return 4;
                    if (prop.propertyValueType === PropertyValueType.TEXT_DOCUMENT) return "text";
                }
                // Fallbacks
                if (prop.propertyValueType === 1) return 1;
                if (prop.propertyValueType === 2) {
                    if (this.isLayer3D(layer)) return 3;
                    return 2;
                }
                if (prop.propertyValueType === 3) return 3;
                if (prop.propertyValueType === 4) return 4;
                if (prop.propertyValueType === 7) return "text";

                if (prop.value instanceof Array) {
                    return prop.value.length;
                }
                if (typeof prop.value === "number") return 1;
                if (typeof prop.value === "string") return "text";
            } catch (e) {}
            return 1;
        }
    };
})();
