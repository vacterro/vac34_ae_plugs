/**
 * vac34_AE Host Smoke Test Runner
 * Validates ScriptUI controls, layout execution, dimensions, and operational behavior in After Effects 2024 runtime.
 * Writes diagnostic smoke report for non-interactive automated verification.
 */

(function(thisObj) {
    "use strict";

    var results = {
        timestamp: (new Date()).toISOString ? (new Date()).toISOString() : String(new Date()),
        hostName: (typeof app !== "undefined" && app.name) ? app.name : "Mock/External",
        hostVersion: (typeof app !== "undefined" && app.version) ? app.version : "Unknown",
        panelCreated: false,
        dockedMode: false,
        titleVerified: false,
        searchBoxPresent: false,
        categoriesPresent: false,
        recipeListPopulated: false,
        paramPanelPresent: false,
        actionButtonsPresent: false,
        initialLayoutPerformed: false,
        buildIdVerified: false,
        status: "HOST_UNVERIFIED",
        errors: []
    };

    try {
        var isPanel = (typeof Panel !== "undefined" && (thisObj instanceof Panel));
        results.dockedMode = isPanel;

        if (typeof vac34_UIBuilder === "undefined") {
            results.errors.push("vac34_UIBuilder is not defined in global scope.");
            return results;
        }

        var win = vac34_UIBuilder.build(thisObj);
        if (!win) {
            results.errors.push("vac34_UIBuilder.build() returned null or undefined.");
            return results;
        }

        results.panelCreated = true;

        // Traverse children to verify presence of UI controls
        var children = win.children || [];
        for (var i = 0; i < children.length; i++) {
            var c = children[i];
            if (c.children) {
                for (var j = 0; j < c.children.length; j++) {
                    var sub = c.children[j];
                    if (sub.text && sub.text.indexOf("vac34_AE") !== -1) {
                        results.titleVerified = true;
                        if (typeof vac34_Config !== "undefined" && sub.text.indexOf(vac34_Config.BUILD_ID) !== -1) {
                            results.buildIdVerified = true;
                        }
                    }
                    if (sub.type === "edittext" || (sub.helpTip && sub.helpTip.indexOf("Search") !== -1)) {
                        results.searchBoxPresent = true;
                    }
                    if (sub.type === "dropdownlist") {
                        results.categoriesPresent = true;
                    }
                    if (sub.type === "listbox") {
                        results.recipeListPopulated = true;
                    }
                }
            }
            if (c.type === "panel" && c.text === "Parameters") {
                results.paramPanelPresent = true;
            }
            if (c.text && c.text.indexOf("Apply Behavior") !== -1) {
                results.actionButtonsPresent = true;
            }
        }

        if (win.layout) {
            win.layout.layout(true);
            win.layout.resize();
            results.initialLayoutPerformed = true;
        }

        if (typeof Window !== "undefined" && (win instanceof Window)) {
            win.close();
        }

        if (results.panelCreated && results.titleVerified && results.buildIdVerified) {
            results.status = (typeof app !== "undefined" && app.name === "Adobe After Effects") ? "VERIFIED" : "HOST_UNVERIFIED";
        }

    } catch (e) {
        results.errors.push(e.message || String(e));
        results.status = "FAILED";
    }

    // Write diagnostic report to user data folder if available
    try {
        if (typeof Folder !== "undefined" && typeof File !== "undefined") {
            var targetDir = new Folder(Folder.userData.fsName + "/vac34_AE");
            if (!targetDir.exists) targetDir.create();
            var repFile = new File(targetDir.fsName + "/smoke_report.json");
            repFile.open("w");
            repFile.write(JSON.stringify ? JSON.stringify(results, null, 2) : String(results));
            repFile.close();
        }
    } catch (errWrite) {}

    return results;
})(typeof thisObj !== "undefined" ? thisObj : null);
