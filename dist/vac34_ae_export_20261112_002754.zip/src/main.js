/**
 * vac34_AE — Master Expressions Studio
 * Version 0.0.1
 * Entry Point
 */

try {
    if (typeof vac34_UIBuilder !== "undefined") {
        var ui = vac34_UIBuilder.build(thisObj);
        if (ui) {
            // The panel owns its geometry (fixed header/footer + scrollable
            // viewport): ask it to reflow instead of re-flowing manually,
            // which would undo the manual positions.
            if (typeof ui.refreshLayout === "function") {
                ui.refreshLayout(true);
            } else if (ui.layout) {
                ui.layout.layout(true);
            }
            if (typeof Window !== "undefined" && (ui instanceof Window)) {
                ui.center();
                ui.show();
            } else if (ui.layout) {
                ui.layout.resize();
            }
        }
    }
} catch (e) {
    var stage = (typeof vac34_Diagnostics !== "undefined") ? vac34_Diagnostics.getCurrentStartupStage() : "Startup";
    if (thisObj && typeof thisObj === "object" && thisObj.layout) {
        try {
            thisObj.layout.layout(true);
            thisObj.layout.resize();
        } catch (layErr) {}
    }
    if (typeof alert !== "undefined") {
        alert("vac34_AE Initialization Error [" + stage + "]: " + (e.message || e) + (e.line ? ("\nLine: " + e.line) : ""));
    }
}
